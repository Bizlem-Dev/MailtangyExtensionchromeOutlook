﻿var syncDiff = 0 * 24 * 60 * 60 * 1000; //should be in milliseconds
var AuthUrls = {
    LOGIN_URL: "https://login.salesforce.com/services/oauth2/authorize?response_type=code&client_id=3MVG9d8..z.hDcPLTrjNrmyBE6aaQd4ppOmDoPDosVQgzlKdbddzLx48u68paKUn8o_UK2ZcZBFu9aQ7_DFPz&redirect_uri=https://application.mailtangy.com:8443/SFDC/redirect",
    LOGIN_CALLBACK_URL: "https://application.mailtangy.com:8443/SFDC/redirect",
    REFRESH_TOKEN_URL: "http://application.mailtangy.com:8080/SFDC/getTokenRefreshToken.token?type=code&code=",
}
// var BaseUrl = "http://35.199.43.21:8080/SFDC/";
var BaseUrl = "http://application.mailtangy.com:8080/SFDC/";
var owner = null;
// var BaseUrlforDisplayCase="http://application.mailtangy.com:8080/SFDC/";
// var BaseUrlForEventHandler="http://application.mailtangy.com:8080/SFDC/";

var GuestUrls = {
    GetGmailProfile: 'getGmailProfile.gmailprofile?p_email=todo@gmail.com',
    GetEmailTemplate: 'SelectTemplates.getdata?email=todo@gmail.com',
    //SocialProfile: 'SocialProfileServlet?p_email=todo@gmail.com',
    MailDataBased: 'MailDataBasedOnEmail.getdata?email=todo@gmail.com',
    UserFeaturesSaved: 'checkEmailInFeaturesServlet.check?email=todo@gmail.com',
    FeatureServletNew: 'featureServletNew.addnode',
    SentimentServlet: 'SentimentServlet.getdata?email=todo@gmail.com',
    DisplayAutoReply: '',
    GetSocialProfile: ''
}
var SFDCAuthUrls = {
    SummerizerServlet: 'summerizerServlet.summery',
    SearchCase: 'SearchConstrainData.searchConstrain',
    CreateNewTask: 'createSfObject.newtask',
    CreateNewCase: 'createSfObject.newcase',
    CreateNewLead: 'createSfObject.newlead',
    DisplayAllTasks: 'DisplayAllTasks.displayalltasks',
    DisplayCase: 'displayCase.allcase?rm_email=todo@gmail.com&type=all',
    DisplayCaseBasedOnEmail: 'displayCaseBasedOnEmail.displaycase?rm_email=todo@gmail.com&email=todo@gmail.com',
    CoseCaseServlet: 'closeCaseServlet.caseclose',
    eventHandlerServlet: 'eventHandlerServlet.addnode'
};

var Credentials = {
    code: null,
    data: null
}


chrome.extension.onRequest.addListener(function (request, sender, sendResponse) {
    switch (request.cmd) {
        case "bg_read_file":
            {
                $.ajax({
                    url: chrome.extension.getURL("/page-template/mail-tangy-tmpl.html"),
                    dataType: "html",
                    headers: {
                        'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
                    },
                    success: sendResponse
                });
                //chrome.tabs.create({ "url": chrome.extension.getURL('login.html'), "selected": true });
            }
            break;
        case "bg_open_login_page":
            {
                chrome.tabs.create({ "url": AuthUrls.LOGIN_URL, "selected": true });
            }
            break;
        case "bg_HttpGet":
            {
                var url = BaseUrl + GuestUrls[request.urlName];
                if (request.Query) {
                    $.each(request.Query, function (name, value) {
                        url = AddUpdateQueryStringParameter(url, name, value);
                    });
                }
                $.ajax({
                    url: url,
                    headers: {
                        'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
                    },
                    success: sendResponse
                });
            }
            break;
        case "bg_HttpPost":
            {
                var url = BaseUrl + GuestUrls[request.urlName];
                $.ajax({
                    method: "POST",
                    url: url,
                    headers: {
                        'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
                    },
                    data: request.Query,
                    success: sendResponse
                });
            }
            break;

        case "bg_HttpGet_auth":
            {
                var url = BaseUrl + SFDCAuthUrls[request.urlName];
                console.log("request.Query====>", request.Query);
                if (request.Query) {
                    $.each(request.Query, function (name, value) {
                        url = AddUpdateQueryStringParameter(url, name, value);
                    });
                }
                GetRefrashTokan(function (accessTokan, instance_url) {
                    //  alert("bg_HttpGet_auth "+ instance_url);
                    //alert(accessTokan)
                    url = AddUpdateQueryStringParameter(url, "access_token", accessTokan);
                    url = AddUpdateQueryStringParameter(url, "instance_url", instance_url);
                    //
                });

                $.ajax({
                    url: url,
                    headers: {
                        'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
                    },
                    success: sendResponse
                });
            }
            break;
        case "bg_signout":
            {
                Credentials = {
                    code: null,
                    data: null
                }
                chrome.storage.local.remove(["tokenData"], sendResponse);
            }
            break;
        default:
            break;
    }
});

chrome.runtime.onMessageExternal.addListener(function (request, sender, sendResponse) {
    switch (request.cmd) {
        case 'bg_get_user_sync_time':
            {
                var name = request.name;
                var cookieData = getCookie(name);
                owner = name;
                console.log("cookieData owner " + owner);

                if (cookieData == null || cookieData == "") {
                    lastSyncTime = parseInt((new Date().getTime() - syncDiff) / 1000);
                    console.log("null cookie " + lastSyncTime);
                } else {
                    lastSyncTime = cookieData;

                }

                setCookie(name, lastSyncTime, 30);
                console.log(" set  cookie " + lastSyncTime);
                console.log("Last Sync occured at :", new Date(getCookie(name) * 1000));
                sendResponse({ "lastSyncTime": lastSyncTime });
            }
            break;
        case 'bg_set_user_sync_time':
            {
                var name = request.name;
                var lastSyncTime = request.syncTime;
                //console.log(name, lastSyncTime);
                setCookie(name, lastSyncTime, 30);
                //chrome.storage.local.set({key : value},function(){});
                sendResponse({});
            }
            break;
        case 'bg_send_mail_details':
            {
                var url = BaseUrl + SFDCAuthUrls[request.urlName];
                var form_data = new FormData();
                for (var key in request.Query) {
                    form_data.append(key, request.Query[key]);

                }
                $.each(request.attachments, function (index, attachment) {
                    var blob = new Blob([attachment.data], { type: attachment.mime });
                    form_data.append('attachfiles', blob, attachment.filename);
                    //console.log(url,request.Query, attachment);
                });

                GetRefrashTokan(function (accessTokan, instance_url) {
                    // alert("bg_send "+ instance_url);
                    url = AddUpdateQueryStringParameter(url, "access_token", accessTokan);
                    url = AddUpdateQueryStringParameter(url, "instance_url", instance_url);
                });
                $.ajax({
                    method: 'POST',
                    cache: false,
                    async: false,
                    url: url,
                    headers: {
                        'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
                    },
                    data: form_data,
                    //dataType: 'text/html',
                    success: function (response) {
                        console.log(response);
                        JSON.parse(response);
                        sendResponse(response);
                    },
                    error: function (response) {
                        console.log(response.responseText);
                        sendResponse(response.responseText);
                    },
                    failure: function (respone) {
                        console.log(response.responseText);
                        sendResponse(response.responseText);
                    },
                    contentType: false,
                    processData: false
                });
            }
            break;
        default:
            break;
    }
});
chrome.storage.local.get(["tokenData", "code"], function (data) {

    if (data) {

        if (data.tokenData && data.code) {
            Credentials = {
                code: data.code,
                data: data.tokenData
            };

        }

    }
});


chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    if (tab.url.indexOf(AuthUrls.LOGIN_CALLBACK_URL) >= 0 && changeInfo.status == "complete") {
        Credentials.code = GetQueryStringParameter("code", tab.url);
        //console.log("tab.status = "+changeInfo.status);
        //console.log("tab.url.indexOf = "+tab.url);

        GetRefrashTokan(function (data, data1) {
            // alert("token"+data)
            chrome.tabs.query({ url: "https://mail.google.com/mail/u/*" }, function (tabs) {
                $.each(tabs, function (index, tab) {
                    chrome.tabs.reload(tab.id);
                });
            });
            chrome.tabs.remove(tab.id);
            //console.log("tab removed");
        });
    } else {


    }

    if (tab.url.indexOf("https://www.mailtangy.com/redirect.html") >= 0 && changeInfo.status == "complete") {


        var queryString = decodeURIComponent(tab.url);
        // console.log("queryString ");
        queryString = queryString.substring(1);
        //alert("queryString = "+queryString);
        var queries = queryString.split('&');

        var gmailcode = queries[0].split('=')[1];
        console.log("code = " + gmailcode);

        //    chrome.tabs.remove(tab.id);
        //console.log("tab removed name "+owner);

        GetTokens(gmailcode);
    } else {

        //console.log("tab.url.indexOf = "+tab.url);
        //	console.log("AuthUrls.LOGIN_CALLBACK_URL ====================== "+"www.mailtangy.com");
    }

});
var iCount = 0;
function GetRefrashTokan(callback) {
    var isRequiredRefrashTokan = true;


    if (Credentials.data != null && Credentials.data.issued_at) {
        //  alert("If 1")
        var differenceInSec = Math.floor((new Date()).getTime() / 1000) - Math.floor(Credentials.data.issued_at / 1000);
        var differenceInHr = differenceInSec / 3600;
        if (differenceInHr <= 10) {
            //    alert("If 2")
            isRequiredRefrashTokan = false;
            //   iCount = 0;
        }

    } else {


    }

    if (isRequiredRefrashTokan == false) {
        callback(Credentials.data.access_token, Credentials.data.instance_url);
        //console.log("isRequiredRefrashTokan false =====*************** ");

    } else {
        //callback(Credentials.data.access_token);
        //   if(iCount == 0){
        //alert(iCount);

        $.ajax({
            url: AuthUrls.REFRESH_TOKEN_URL + Credentials.code,
            headers: {
                'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
            },
            async: true,
            success: function (data) {
                //alert("token data::"+data);
                //console.log("ajax success ===== "+data);
                var data = JSON.parse(data);
                Credentials.data = data;
                //alert( data.instance_url);
                //callback(data.access_token,data.instance_url);
                chrome.storage.local.set({ code: Credentials.code, tokenData: data }, callback(data.access_token, data.instance_url));
                //	chrome.storage.local.set({ code: Credentials.code, tokenData: data });

            },
        });
        // iCount=1;
        // }

    }

}


function GetQueryStringParameter(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}


function AddUpdateQueryStringParameter(uri, key, value) {
    var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
    var separator = uri.indexOf('?') !== -1 ? "&" : "?";
    if (uri.match(re)) {
        return uri.replace(re, '$1' + key + "=" + value + '$2');
    }
    else {
        return uri + separator + key + "=" + value;
    }
}
function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

// Gmail Outh functions get token

function GetTokens(code) {

    var l = this;
    //	var accesstoken="ya29.GluqBkJpUDpbLsfeNoHnqPf058RPHBInD7_9MoAjvECg4dfMbxA7wmb0Fom79au6iKTxj4bhM_IlwPLuy82tF9nDzBshHy3tUO3G3yWfOr2sE0RdilF7X5bLhN4C";
    var clientId = "712722641906-ki100i2u7q647eateb4gifmphpcoj97r.apps.googleusercontent.com"; // client id and secret used from sanjay singh project Mailclient
    var clientSecret = "qE-Texkpzo0KR-51XgOIfyas";
    var red = "http://www.mailtangy.com/redirect.html";
    var rfs = "";
    console.log("owner : " + owner);
    $.ajax({
        url: 'https://www.googleapis.com/oauth2/v4/token',
        type: "post",
        datatype: "json",
        contentType: "application/x-www-form-urlencoded; charset=utf-8",
        async: true,
        data: { code: code, client_id: clientId, client_secret: clientSecret, redirect_uri: red, grant_type: 'authorization_code' },
        success: function (response) {
            //    console.log("Response: " + response);
            //   console.log("AT: " + response['access_token']);
            console.log("RT: " + response['refresh_token']);

            access_token = response['access_token'];
            refresh_token = response['refresh_token'];
            rfs = refresh_token;
            //alert("access_token -- "+access_token);

            $.ajax({
                url: 'https://application.mailtangy.com:8443/SFDC/SaveRFToken.set',
                type: "get",

                data: {
                    RefreshToken: rfs, email: owner
                },
                success: function (response) {
                    //alert(" response = "+response);
                    console.log("Response: " + response);


                }
            });


        }
    })
        .fail(function (err) {
            //   alert("error 11111111111111111 co expiregettokens    " + err); //[Object object]

        });

}

