﻿﻿var syncDiff = 0*24*60*60*1000; //should be in milliseconds
var AuthUrls = {
    LOGIN_URL: "https://login.salesforce.com/services/oauth2/authorize?response_type=code&client_id=3MVG9d8..z.hDcPLjr5f1MlEDAMPIK_IYtZldOuMrwewUKGtzz4rj.SImppH_jHYk4L2preyxjS96TsILDs.a&redirect_uri=https://35.188.249.145:8443/SFDC",
    LOGIN_CALLBACK_URL: "https://35.188.249.145:8443/SFDC",
    REFRESH_TOKEN_URL: "http://35.188.249.145:8080/SFDC/getTokenRefreshToken?type=code&code=",
}
var BaseUrl = "http://35.188.249.145:8080/SFDC/";

var GuestUrls = {
    GetGmailProfile: 'getGmailProfile?p_email=todo@gmail.com',
    GetEmailTemplate: 'SelectTemplates?email=todo@gmail.com',
    //SocialProfile: 'SocialProfileServlet?p_email=todo@gmail.com',
    MailDataBased: 'MailDataBasedOnEmail?email=todo@gmail.com',
    UserFeaturesSaved: 'checkEmailInFeaturesServlet?email=todo@gmail.com',
    FeatureServletNew: 'featureServletNew',
    SentimentServlet: 'SentimentServlet?email=todo@gmail.com',
    DisplayAutoReply: 'displayAutoReply?rm_email=todo@gmail.com',
    GetSocialProfile: 'getSocialProfile?email=rohit.varma0090@gmail.com'
}
var SFDCAuthUrls = {
    SummerizerServlet: 'summerizerServlet',
    DisplayCase: 'displayCase?rm_email=todo@gmail.com&type=all',
    DisplayCaseBasedOnEmail: 'displayCaseBasedOnEmail?rm_email=todo@gmail.com&email=todo@gmail.com',
    CoseCaseServlet: 'closeCaseServlet',
    eventHandlerServlet : 'eventHandlerServlet'
};

var Credentials = {
    code: null,
    data: null
}

chrome.extension.onRequest.addListener(function (request, sender, sendResponse) {
    switch (request.cmd) {
        case "bg_read_file":
            {
                $.ajax({
                    url: chrome.extension.getURL("/page-template/mail-tangy-tmpl.html"),
                    dataType: "html",
					headers: {
						'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
					},
                    success: sendResponse
                });
                //chrome.tabs.create({ "url": chrome.extension.getURL('login.html'), "selected": true });
            }
            break;
        case "bg_open_login_page":
            {
                chrome.tabs.create({ "url": AuthUrls.LOGIN_URL, "selected": true });
            }
            break;
        case "bg_HttpGet":
            {
                var url = BaseUrl + GuestUrls[request.urlName];
                if (request.Query) {
                    $.each(request.Query, function (name, value) {
                        url = AddUpdateQueryStringParameter(url, name, value);
                    });
                }
                $.ajax({
                    url: url, 
					headers: {
						'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
					},
					success: sendResponse
                });
            }
            break;
        case "bg_HttpPost":
            {
                var url = BaseUrl + GuestUrls[request.urlName];
                $.ajax({
                    method: "POST",
                    url: url,
					headers: {
						'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
					},
                    data: request.Query,
                    success: sendResponse
                });
            }
            break;
        case "bg_HttpGet_auth":
            {
                var url = BaseUrl + SFDCAuthUrls[request.urlName];
                if (request.Query) {
                    $.each(request.Query, function (name, value) {
                        url = AddUpdateQueryStringParameter(url, name, value);
                    });
                }
                GetRefrashTokan(function (accessTokan) {
                   
                    //alert(accessTokan)
                    url = AddUpdateQueryStringParameter(url, "access_token", accessTokan);
                });
                $.ajax({
                    url: url,
					headers: {
						'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
					},
                    success: sendResponse
                });
            }
            break;
        case "bg_signout":
            {
                Credentials = {
                    code: null,
                    data: null
                }
                chrome.storage.local.remove(["tokenData"], sendResponse);
            }
            break;        
        default:
        	break;
    }
});
chrome.runtime.onMessageExternal.addListener(function (request, sender, sendResponse) {
	switch (request.cmd) {
		case 'bg_get_user_sync_time':
		{
			var name = request.name;
			var cookieData = getCookie(name);
			if(cookieData == null || cookieData == ""){
				lastSyncTime = parseInt((new Date().getTime()-syncDiff)/1000);
			} else {
				lastSyncTime = cookieData;
			}
			setCookie(name, lastSyncTime, 30);
			console.log("Last Sync occured at :", new Date(getCookie(name)*1000));
			sendResponse({"lastSyncTime" : lastSyncTime });
		}
		break;
		case 'bg_set_user_sync_time':
		{
			var name = request.name;
			var lastSyncTime = request.syncTime;
			//console.log(name, lastSyncTime);
			setCookie(name, lastSyncTime, 30);
			//chrome.storage.local.set({key : value},function(){});
			sendResponse({});
		}
		break;
		case 'bg_send_mail_details':
		{
			var url = BaseUrl + SFDCAuthUrls[request.urlName];
			var form_data = new FormData();
			for ( var key in request.Query ) {
				form_data.append(key, request.Query[key]);
			}
			$.each(request.attachments,function(index, attachment){
				var blob = new Blob([attachment.data], { type: attachment.mime });
				form_data.append('attachfiles', blob,attachment.filename);
				//console.log(url,request.Query, attachment);
			});
			
			GetRefrashTokan(function (accessTokan) {
				url = AddUpdateQueryStringParameter(url, "access_token", accessTokan);
			});
			$.ajax({
				method:'POST',
				cache: false,
				async: false,
				url: url,
				headers: {
						'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
					},
				data: form_data,
				dataType: 'text/html',
				success: function(response){
					//console.log(response);
					JSON.parse(response);
					sendResponse(response);
				},
				error: function(response){
					//console.log(response.responseText);
					sendResponse(response.responseText);
				},
				failure: function(respone){
					//console.log(response.responseText);
					sendResponse(response.responseText);
				},
				//contentType: false,
				processData: false
			});
		}
		break;
		default:
		break;
	}
});
chrome.storage.local.get(["tokenData", "code"], function (data) {
    if (data) {

        if (data.tokenData && data.code) {
            Credentials = {
                code: data.code,
                data: data.tokenData
            };
        }
    }
});


chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    if (tab.url.indexOf(AuthUrls.LOGIN_CALLBACK_URL) >= 0 && tab.status == "complete") {
        Credentials.code = GetQueryStringParameter("code", tab.url);
        GetRefrashTokan(function (data) {
          alert("token"+data)
            chrome.tabs.query({ url: "https://mail.google.com/mail/u/*" }, function (tabs) {
                $.each(tabs, function (index, tab) {
                    chrome.tabs.reload(tab.id);
                });
            });
            chrome.tabs.remove(tab.id);
        });
    }
});
var iCount = 0;
function GetRefrashTokan(callback) {
    var isRequiredRefrashTokan = true;
    //alert("Credentials.data:::"+Credentials.data)
    //alert("Credentials.data.issued_at:::"+Credentials.data.issued_at)
    if (Credentials.data != null && Credentials.data.issued_at) {
      //  alert("If 1")
        var differenceInSec = Math.floor((new Date()).getTime() / 1000) - Math.floor(Credentials.data.issued_at / 1000);
        var differenceInHr = differenceInSec / 3600;
        if (differenceInHr <= 10) {
        //    alert("If 2")
            isRequiredRefrashTokan = false;
            iCount = 0;
        }
    }

    if (isRequiredRefrashTokan == false) {
        callback(Credentials.data.access_token);
    } else {
        //callback(Credentials.data.access_token);
        if(iCount == 0){
        alert(iCount);
        $.ajax({
            url: AuthUrls.REFRESH_TOKEN_URL + Credentials.code,
			headers: {
						'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
					},
            async:true,
            success: function (data) {
                var data = JSON.parse(data)
                Credentials.data = data;
                chrome.storage.local.set({ code: Credentials.code, tokenData: data }, callback(data.access_token));
            },
        });
        iCount=1;
    }
    }
}


function GetQueryStringParameter(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}


function AddUpdateQueryStringParameter(uri, key, value) {
    var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
    var separator = uri.indexOf('?') !== -1 ? "&" : "?";
    if (uri.match(re)) {
        return uri.replace(re, '$1' + key + "=" + value + '$2');
    }
    else {
        return uri + separator + key + "=" + value;
    }
}
function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}