! function () {
    var e, a, t = "285740687692-fbhi79lu52jp2kae5rhpm97lftsq45ug.apps.googleusercontent.com",
        n = "AIzaSyCrNiA6b9qdxefQ_buzSr6W2947w38rAsQ",
        s = "https://www.googleapis.com/auth/gmail.labels https://www.googleapis.com/auth/gmail.modify",
        i = "me",
        r = !0,
        l = {},
        o = document.getElementById("mt-app").getAttribute("extnId");
//client id and api key used from sanjay singh project Mail Tangy
    //function c() {
    //    gapi.auth2.authorize({
    //        client_id: t,
    //        scope: s,
    //        immediate: !0
    //    }, u)
    //}

    //function u(e) {
    //    e && !e.error ? d(e) : (r && gapi.auth.authorize({
    //        client_id: t,
    //        scope: s,
    //        immediate: !1
    //    }, u), r = !1)
    //}

    function c() {
        gapi.auth2.authorize({
            client_id: t,
            scope: s,
            immediate: !0,
            cookie_policy: 'none',
            prompt: 'none'
        }, u)
    }

    function u(e) {
        e && !e.error ? d(e) : (r && gapi.auth2.authorize({
            client_id: t,
            scope: s,
            immediate: !1,
            cookie_policy: 'none',
        }, u), r = !1)
    }

    function d(e) {
        gapi.client.load("gmail", "v1", m)
    }

    function m() {
        gapi.client.gmail.users.messages.list({
            userId: "me",
            labelIds: "INBOX",
            maxResults: 1
        }).execute(function (t) {
            var n = t.messages || [],
                s = (n = n[0]).id,
                r = gapi.client.gmail.users.messages.get({
                    userId: i,
                    id: s
                });
            y(), r.execute(function (t) {
                var n = t.payload;
                e = h(n.headers, "Delivered-To"), a = e.replace(/=/gi, ""), chrome.runtime.sendMessage(o, {
                    cmd: "bg_get_user_sync_time",
                    name: a
                }, function (e) {
                    p(e.lastSyncTime)
                })
            })
        })
    }

    function p(e) {
        var t = g,
            n = parseInt((new Date).getTime() / 1e3),
            s = "after:" + (e - 1) + " before:" + n + " AND NOT label:Case AND NOT label:Lead",
            r = function (e, l) {
                e.execute(function (c) {
                    c.messages = c.messages || [], l = l.concat(c.messages);
                    var u = c.nextPageToken;
                    u ? (e = gapi.client.gmail.users.messages.list({
                        userId: i,
                        pageToken: u,
                        q: s
                    }), r(e, l)) : (t(l), l.length > 0 && chrome.runtime.sendMessage(o, {
                        cmd: "bg_set_user_sync_time",
                        name: a,
                        syncTime: n
                    }, function (e) { }))
                })
            },
            l = gapi.client.gmail.users.messages.list({
                userId: i,
                q: s
            });
        r(l, [])
    }

    function g(e) {
        for (var a = 0; a < e.length; a++) {
            var t = e[a].id;
            gapi.client.gmail.users.messages.get({
                userId: i,
                id: t
            }).execute(f)
        }
    }

    function f(e) {
        console.log("message", e);
        var a = h(e.payload.headers, "Received");
        a = a || "", a = (a = $.trim(a.split(";")[1])) || "", a = $.trim(a.split("(")[0]);
        var t = "";
        try {
            t += new Date(parseInt(e.internalDate))
        } catch (e) { }
        var n = {
            source: "Gmail",
            id: e.id,
            to: h(e.payload.headers, "To"),
            from: h(e.payload.headers, "From"),
            subject: h(e.payload.headers, "Subject"),
            seen: t,
            sentdate: h(e.payload.headers, "Date"),
            receiveddate: a,
            HtmlMessagebody: function (e) {
                var a = "";
                a = void 0 === e.parts ? e.body.data : function e(a) {
                    for (var t = 0; t <= a.length; t++) {
                        if (void 0 !== a[t].parts) return e(a[t].parts);
                        if ("text/html" === a[t].mimeType) return a[t].body.data
                    }
                    return ""
                }(e.parts);
                return a = a.replace(/-/g, "+").replace(/_/g, "/").replace(/\s/g, ""), decodeURIComponent(escape(window.atob(a)))
            }(e.payload),
            PlainTextMessagebody: e.snippet
        };
        ! function (e, a, t) {
            a.payload = a.payload || {};
            for (var n = a.payload.parts || [], s = n.length, i = [], r = 0; r < n.length; r++) {
                var c = n[r];
                if (c.filename && c.filename.length > 0) {
                    var u = c.body.attachmentId,
                        d = gapi.client.gmail.users.messages.attachments.get({
                            id: u,
                            messageId: a.id,
                            userId: e
                        });
                    d.execute(function (e) {
                        i.push({
                            filename: c.filename,
                            mime: c.mimeType,
                            data: e.data
                        }), s -= 1
                    })
                } else s -= 1
            }
            var m = setInterval(function () {
                0 == s && (clearInterval(m), chrome.runtime.sendMessage(o, {
                    cmd: "bg_send_mail_details",
                    urlName: "eventHandlerServlet",
                    Query: t,
                    attachments: i
                }, function (t) {
                    // alert("Eventhandler data::"+t);
                    // if (null != (t = JSON.parse(t)) && "true" == t.auto_reply_status) {     ||"false" == t.auto_reply_status
                    if (null != (t = JSON.parse(t)) && ("true" == t.auto_reply_status)) {
                        var n = h(a.payload.headers, "From"),
                            s = t.replySubject,
                            i = t.replyText;
                        attachments = t.attachments || [],
                            function (a, t, n, s) {
                                var i = ['Content-Type: multipart/mixed; boundary="karthik_21_at_live_in"\r\n', "MIME-Version: 1.0\r\n", "To: " + a.To + "\r\n", "Subject: " + a.Subject + "\r\n\r\n", "In-Reply-To: " + a["In-Reply-To"] + "\r\n\r\n", "--karthik_21_at_live_in\r\n", 'Content-Type: text/html; charset="UTF-8"\r\n', "MIME-Version: 1.0\r\n", "Content-Transfer-Encoding: 7bit\r\n\r\n", t + "\r\n\r\n"];
                                for (fileIndex in n) {
                                    var r = n[fileIndex];
                                    i.push("--karthik_21_at_live_in\r\n"), i.push("Content-Type: " + r.contentType + "\r\n"), i.push("MIME-Version: 1.0\r\n"), i.push("Content-Transfer-Encoding: base64\r\n"), i.push('Content-Disposition: attachment; filename="' + r.fileName + '"\r\n\r\n'), i.push(r.data), i.push("\r\n\r\n"), i.push("--karthik_21_at_live_in\r\n")
                                }
                                i.push("--karthik_21_at_live_in--"), i = i.join(""), gapi.client.gmail.users.messages.send({
                                    userId: e,
                                    resource: {
                                        raw: window.btoa(i).replace(/\+/g, "-").replace(/\//g, "_")
                                    }
                                }).execute(s)
                            }
                                ({
                                    To: n,
                                    Subject: s,
                                    "In-Reply-To": a.id
                                }, i, attachments, null),

                            null != t.label && t.label.toLowerCase().indexOf("case") > -1 ? t.label = "Case" : null != t.label && t.label.toLowerCase().indexOf("lead") > -1 ? t.label = "Lead" : t.label = "";
                        var r = l[t.label];
                        if (null != r) gapi.client.gmail.users.messages.modify({
                            userId: e,
                            id: a.id,
                            addLabelIds: [r]
                        }).execute(function () {
                            $('a[href="https://mail.google.com/mail/u/0/#inbox]"').click();
                        });
                    }
                    else {

                        var n = h(a.payload.headers, "From"),
                            s = t.replySubject,
                            i = t.replyText;
                        attachments = t.attachments || [],
                            function (a, t, n, s) {
                                var i = ['Content-Type: multipart/mixed; boundary="karthik_21_at_live_in"\r\n', "MIME-Version: 1.0\r\n", "To: " + a.To + "\r\n", "Subject: " + a.Subject + "\r\n\r\n", "In-Reply-To: " + a["In-Reply-To"] + "\r\n\r\n", "--karthik_21_at_live_in\r\n", 'Content-Type: text/html; charset="UTF-8"\r\n', "MIME-Version: 1.0\r\n", "Content-Transfer-Encoding: 7bit\r\n\r\n", t + "\r\n\r\n"];
                                for (fileIndex in n) {
                                    var r = n[fileIndex];
                                    i.push("--karthik_21_at_live_in\r\n"), i.push("Content-Type: " + r.contentType + "\r\n"), i.push("MIME-Version: 1.0\r\n"), i.push("Content-Transfer-Encoding: base64\r\n"), i.push('Content-Disposition: attachment; filename="' + r.fileName + '"\r\n\r\n'), i.push(r.data), i.push("\r\n\r\n"), i.push("--karthik_21_at_live_in\r\n")
                                }
                                // i.push("--karthik_21_at_live_in--"), i = i.join(""), gapi.client.gmail.users.messages.send({
                                //     userId: e,
                                //     resource: {
                                //         raw: window.btoa(i).replace(/\+/g, "-").replace(/\//g, "_")
                                //     }
                                // }).execute(s)
                            }
                                ({
                                    To: n,
                                    Subject: s,
                                    "In-Reply-To": a.id
                                }, i, attachments, null),

                            null != t.label && t.label.toLowerCase().indexOf("case") > -1 ? t.label = "Case" : null != t.label && t.label.toLowerCase().indexOf("lead") > -1 ? t.label = "Lead" : t.label = "";
                        var r = l[t.label];
                        if (null != r) gapi.client.gmail.users.messages.modify({
                            userId: e,
                            id: a.id,
                            addLabelIds: [r]
                        }).execute(function () {
                            $('a[href="https://mail.google.com/mail/u/0/#inbox]"').click();
                        });

                    }


                }))
            }, 2e3)
        }(i, e, n)
    }

    function h(e, a) {
        var t = "";
        return $.each(e, function () {
            this.name.toLowerCase() === a.toLowerCase() && (t = this.value)
        }), t
    }

    setTimeout(function () {
        gapi.client.setApiKey(n), setTimeout(c, 1);
    }, 5e3), setInterval(d, 18e5), setInterval(function () {
        chrome.runtime.sendMessage(o, {
            cmd: "bg_get_user_sync_time",
            name: a
        }, function (e) {
            p(e.lastSyncTime)
        })
    }, 6e4);

    function y() {
        gapi.client.gmail.users.labels.list({
            userId: i
        }).execute(function (e) {
            labelsList = e.labels || [], $.each(labelsList, function (e, a) {
                l[a.name] = a.id
            }), null == l.Case ? v("Case", y) : null == l.Lead && v("Lead", y)
        })
    }

    function v(e, a) {
        gapi.client.gmail.users.labels.create({
            userId: i,
            resource: {
                name: e,
                labelListVisibility: 'labelShow',
                messageListVisibility: 'show'
            }
        }).execute(a)
    }

    setInterval(function () {
        $(".av:contains(Lead)").each(function () {
            var e = $(this).closest("tr").find("td.yX");
            $(e).find(".lead").length <= 0 && $(e).find(".yW").prepend('<span class="lead" title="Lead Ticket"></span>')
        }), $(".av:contains(Case)").each(function () {
            var e = $(this).closest("tr").find("td.yX");
            $(e).find(".cases").length <= 0 && $(e).find(".yW").prepend('<span class="cases" title="Case Ticket"></span>')
        })
    }, 1e3)
}();