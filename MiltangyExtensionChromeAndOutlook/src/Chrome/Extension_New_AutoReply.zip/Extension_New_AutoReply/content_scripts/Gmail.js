﻿InboxSDK.load('1', 'sdk_rupaparapankaj_32b6a78c77').then(function (sdk) {

    $(".AO").parent().append("<p class='AO-right'>Loading..</p>")

    chrome.extension.sendRequest({cmd: "bg_read_file"}, function (html) {
        $(".AO-right").html(html);
    });

    setTimeout(function () {
        var myApp = angular.module('myApp', []);
        myApp.config(['$compileProvider',
            function ($compileProvider) {
                $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|chrome-extension):/);
                $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|ftp|mailto|chrome-extension):/);
            }]);

        myApp.filter('truncate', function () {
            return function (text, length, end) {

                if (isNaN(length))
                    length = 10;

                if (end === undefined)
                    end = "...";

                if (text.length <= length || text.length - end.length <= length) {
                    return text;
                }
                else {
                    return String(text).substring(0, length - end.length) + end;
                }
            };
        });

        myApp.filter('strDate', function ($filter) {
            return function (input) {
                var date = new Date(input);
                return ($filter('date')(date, 'MMM/dd/yy HH:mm'));
            }
        });

        myApp.filter('displayPageData', function () {
            return function (input, start) {
                start = +start; //parse to int
                return input.slice(start);
            }
        });

        myApp.controller('BaseController', function ($scope, $rootScope) {
            $scope.pageList = ['login', 'feature', 'opencasepage', 'info'];
            $rootScope.currentPage = 'login';
            $rootScope.Resource = {
                headingLogoUrl: chrome.extension.getURL("/icons/mailtangy-logo.png"),
                salseLogoUrl: chrome.extension.getURL("/icons/salesforce.png"),
                lodingImageUrl: chrome.extension.getURL("/icons/Eclipse.gif"),
                Positive: chrome.extension.getURL('icons/smile_1.png'),
                Neutral: chrome.extension.getURL('icons/smile_2.png'),
                Negative: chrome.extension.getURL('icons/smile_3.png'),
                Autoreply: chrome.extension.getURL('icons/Autoreplied.png'),
                ChilliLogo: chrome.extension.getURL('icons/Autoreplied.png'),
            };
            $rootScope.CurrentLoginGmailUser = {
                Email: sdk.User.getEmailAddress()
            };
            //TODO remove this line.
            //$rootScope.CurrentLoginGmailUser.Email = 'ram.gupta9964@gmail.com';

            $rootScope.ShowSpinner = false;
            $rootScope.IsUserFeaturesSaved;

            $scope.initBase = function () {
                chrome.storage.local.get(["tokenData", "code"], function (items) {
                    // console.log(items);
                    if (items && items.tokenData) {
                        chrome.extension.sendRequest({
                            cmd: "bg_HttpGet", urlName: "UserFeaturesSaved", Query: {
                                email: $rootScope.CurrentLoginGmailUser.Email
                            }
                        }, function (data) {
                            var data = JSON.parse(data);
                            //alert(data);
                            if (!data) {
                                // alert("if ::  " + data);
                                $rootScope.IsUserFeaturesSaved = false;
                                $rootScope.currentPage = 'feature';
                            } else {
                                // alert("if else ::  " + data);
                                $rootScope.IsUserFeaturesSaved = true;
                                $rootScope.SetViewBaseOnListAndThrad(items);
                            }
                            $rootScope.$apply();
                        });
                    }
                });
                sdk.Compose.registerComposeViewHandler(function (composeView) {
                    if (composeView.isInlineReplyForm()) {
                        composeView.addButton({
                            title: "Mail Tangy Template",
                            type: "MODIFIER",
                            iconClass: "Small",
                            iconUrl: chrome.extension.getURL('icons/mailtangylogo.png'),
                            hasDropdown: true,
                            onClick: function (menu) {
                                if ($rootScope.EmailTempateList.length >= 0) {
                                    var DropdownHTML = '<div class="tm-reply"> ';
                                    angular.forEach($rootScope.EmailTempateList, function (item, key) {
                                        DropdownHTML += "<div class='item' index=" + item.id + ">" + item.temp_name + "</div>";
                                    });
                                    DropdownHTML += "</div>";
                                }
                                menu.dropdown.el.innerHTML = DropdownHTML;
                                $('.tm-reply .item').click(function (element) {
                                    var temlate = $rootScope.EmailTempateList[$(this).attr('index')].temp_txt;
                                    sdk.Compose.registerComposeViewHandler(function (composeView) {
                                        composeView.setBodyHTML(temlate);
                                    });
                                });
                            },
                        });
                    }
                });
            }
            $(window).on('hashchange', function () {
                chrome.storage.local.get(["tokenData", "code"], function (items) {
                    if ($rootScope.IsUserFeaturesSaved == true) {
                        $rootScope.SetViewBaseOnListAndThrad(items);
                    }
                });
            });
            $rootScope.SetViewBaseOnListAndThrad = function (items) {
                 console.log("items.tokenData.access_token = "+items.tokenData.access_token);
                if (window.location.hash) {
                    var listview = new RegExp(/#\w+/g);
                    var thradview = new RegExp(/#\w+\/\w{16}/g);
                    if (thradview.test(window.location.hash)) {
                        if (items.tokenData.access_token) {
                            $rootScope.currentPage = 'info';
                            $rootScope.$apply();
                        } else {
                            $rootScope.currentPage = 'login';
                            $rootScope.$apply();
                        }
                        console.log('thrad');
                    } else if(listview.test(window.location.hash)) {
                        if (items.tokenData.access_token) {
							  console.log("items.tokenData.access_token = "+items.tokenData.access_token);
                            $rootScope.currentPage = 'opencasepage';
                            $rootScope.$apply();
                        } else {
							 console.log("items.tokenData.access_token = "+items.tokenData.access_token);
                            $rootScope.currentPage = 'login';
                            $rootScope.$apply();
                        }
                        console.log('list');
                    }
                }
            }
        });

        myApp.controller('LoginController', function ($scope, $rootScope) {
            $scope.Login = function () {
                chrome.extension.sendRequest({
                    cmd: "bg_open_login_page"
                });
            }
        });

        myApp.controller('FeatureController', function ($scope, $rootScope) {
            $scope.FetureList = [
                {
                    id: 1,
                    Name: 'Email to Case Email Based',
                    Selacted: true,
                    Path: '1.png',
                    key: 'Email_to_Case_Email_Based'
                },
                {
                    id: 2,
                    Name: 'Email to Case Lead Based',
                    Selacted: true,
                    Path: '2.png',
                    key: 'Email_to_Case_Lead_Based'
                },
                {
                    id: 3,
                    Name: 'Email to Case Content Based',
                    Selacted: true,
                    Path: '3.png',
                    key: 'Email_to_Case_Content_Based'
                },
                {id: 4, Name: 'Calendar Share', Selacted: true, Path: '4.png', key: "Calendar_Share"},
                {id: 5, Name: 'Mail Merge', Selacted: true, Path: '5.png', key: "Mail_Merge"},
                {id: 6, Name: 'Email Tracking', Selacted: true, Path: '6.png', key: "Email_Tracking"},
                {id: 7, Name: 'Smartphone Templates', Selacted: true, Path: '7.png', key: 'Smartphone_Templates'},
                {id: 8, Name: 'Summarizer', Selacted: true, Path: '8.png', key: 'Summarizer'},
                {
                    id: 9,
                    Name: 'Contact Detail Varification',
                    Selacted: true,
                    Path: '9.png',
                    key: 'Contact_Detail_Varification'
                },
                {
                    id: 10,
                    Name: 'Plug-ins for Gmail, Outlook, Office 365',
                    Selacted: true,
                    Path: '10.png',
                    key: 'plug-ins_for_gmail_outlook_office_365'
                },
                {id: 11, Name: 'Productivity Meter', Selacted: true, Path: '11.png', key: 'productivity_meter'},
                {id: 12, Name: 'Email Templates', Selacted: true, Path: '12.png', key: 'email_templates'},
                {
                    id: 13,
                    Name: 'Create SalesForce Records from Mail Box',
                    Selacted: true,
                    Path: '13.png',
                    key: "Create_SalesForce_Records"
                },
                {id: 14, Name: 'Mail Box inside SFDC', Selacted: true, Path: '14.png', key: 'mail_box_inside_sfdc'},
                {
                    id: 15,
                    Name: 'Lead to Case - Content Based',
                    Selacted: true,
                    Path: '15.png',
                    key: 'lead_to_case_content_based'
                },
                {
                    id: 16,
                    Name: 'Content Based - Auto Case Type assignment',
                    Selacted: true,
                    Path: '16.png',
                    key: 'content_based_auto_case_type_assignment'
                },
                {id: 17, Name: 'Sentiment Analysis', Selacted: true, Path: '17.png', key: 'sentiment_analysis'},
                {id: 18, Name: 'Cognitive Auto Reply', Selacted: true, Path: '18.png', key: "cognitive_auto_reply"},
                {
                    id: 19,
                    Name: 'Lead Propensity to buy - Score Productivity Meter',
                    Selacted: true,
                    Path: '19.png',
                    key: 'lead_propensity_to_buy_score_productivity_meter'
                },
                {id: 20, Name: 'Social Footprint', Selacted: true, Path: '20.png', key: 'social_footprint'},
            ];

            angular.forEach($scope.FetureList, function (item, key) {
                item.Path = chrome.extension.getURL("icons/feature/" + item.Path)
            });

            $scope.ShowPrevious = false;
            $scope.ShowNext = true;
            $scope.ShowSave = false;
            $scope.DomainInternal;
            $scope.EmailInternal;


            $scope.Next = function () {
                $scope.ShowPrevious = true;
                $scope.ShowNext = false;
                $scope.ShowSave = true;
            };
            $scope.Previous = function () {
                $scope.ShowPrevious = false;
                $scope.ShowNext = true;
                $scope.ShowSave = false;
            };

            $scope.SaveFeature = function () {
                var query = {};
                angular.forEach($scope.FetureList, function (item, key) {
                    query[item.key] = item.Selacted;
                });
                query.domain = $scope.DomainInternal;
                query.emailid = $scope.EmailInternal;
                query.rm_email = $rootScope.CurrentLoginGmailUser.Email;

                chrome.extension.sendRequest({
                    cmd: "bg_HttpPost", urlName: "FeatureServletNew", Query: query
                }, function (data) {
                    //$rootScope.IsUserFeaturesSaved = true;
                    //$rootScope.$apply();
                    //$rootScope.SetViewBaseOnListAndThrad();
                    toastr.success('Feature save successfully, please wait while setting up for you.', 'Success');
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                });
            }
        });

        myApp.controller('openCasePageController', function ($scope, $rootScope, $filter) {

            $scope.Positive = 0;
            $scope.Neutral = 0;
            $scope.Negative = 0;
            $scope.currentPage = 0;
            $scope.closedCasesPage = 0;
            $scope.autoRepliedPage = 0;
            $scope.searchText = '';
            $scope.pageSize = 7;
            var Loaderhtmldefault = '<div class="Customoverlay" id="Customoverlay1"></div><div class="Customloader" id="Customloader1"></div>';

            chrome.extension.sendRequest({
                cmd: "bg_HttpGet_auth",
                urlName: "DisplayCase",
                Query: {rm_email: $rootScope.CurrentLoginGmailUser.Email}// 'ram.gupta9964@gmail.com'
            }, function (data) {
                // alert("Opencases data"+data)
                if (data) {
                    // alert("Opencases data"+data)
                    $scope.DisplayCase = JSON.parse(data);
                    $scope.$apply();
                }
            });
            $scope.validateEmail = function (email) {
                var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return re.test(email);
            }
            $scope.SearchPopupCall = function (type) {
                $('.CustomPopup').hide();
                if (type == "OK") {
                    if (typeof $('#searchedNameError').html() == "undefined") {
                        var actualnameandemail = $("input[name='searchedName']:checked").val().split('___');
                        console.log("actualnameandemail", actualnameandemail);
                        var actualname = actualnameandemail[0];
                        var actualemail = actualnameandemail[1];
                        var actualid = $('#searchedinput').val();
                    }
                    else {
                        var actualname = $('#searchedNameError').html();
                        var actualid = $('#searchedinput').val();
                    }
                    if (actualname.trim() !== "Unexpected Response From Api" && actualname.trim() !== "No Records Found") {
                        var begning = actualid.replace("Name", "");
                        begning = begning.replace("RelatedTo", "");
                        begning = begning.replace("Contact", "");
                        begning = begning.replace("Account", "");
                        if (actualid.includes('Name') || actualid.includes('Contact')) {
                            $(begning + "searchcontactemail").val(actualemail);
                        }
                        else {
                            $(begning + "searchaccountemail").val(actualemail);
                        }
                        $(actualid).val(actualname);
                    }
                }
                if (type == "OKNEW") {
                    location.reload();
                    $('.openCasePageToBeHidden').show();
                    $('.NTaskContainer').hide();
                }


            }
            $scope.ClearForm = function (formid) {
                $scope.onChangeFunction('MTSelect');
                $('#MTSelect option:selected').removeAttr('selected');
                $("#MTSelect option[value='']").attr('selected', 'selected');
            }
            $scope.SaveForm = function (formid, $event) {
                $('.Customoverlay').remove();
                $('.Customloader').remove();
                $('.positionabsolute').hide();
                $('.customerrorfields').remove();
                $('#' + formid).parent().parent().append(Loaderhtmldefault);
                $('.Customoverlay').show();
                $('.Customloader').show();
                var middleid = "";
                if (formid == "MTNTask1" || formid == "MTNCase1" || formid == "MTNLead1") {
                    middleid = "1";
                }
                if (formid == "MTNTask1" || formid == "MTNTask") {
                    var NtaskAssignedTo = $('#Ntask' + middleid + 'AssignedTo').val();
                    var NtaskSubject = $('#Ntask' + middleid + 'Subject').val();
                    var NtaskPriority = $('#Ntask' + middleid + 'Priority').val();
                    var NtaskStatus = $('#Ntask' + middleid + 'Status').val();
                    var NtaskNameType = $('#Ntask' + middleid + 'NameType').val();
                    var NtaskName = $('#Ntask' + middleid + 'Name').val();
                    var NtaskRelatedToType = $('#Ntask' + middleid + 'RelatedToType').val();
                    var NtaskRelatedTo = $('#Ntask' + middleid + 'RelatedTo').val();
                    var NtaskComment = $('#Ntask' + middleid + 'Comment').val();
                    var Searchcontactemail = $('#Ntask' + middleid + 'searchcontactemail').val();
                    var Searchaccountemail = $('#Ntask' + middleid + 'searchaccountemail').val();
                    var validationsuccess = true;
                    if (NtaskSubject.trim() == '') {
                        validationsuccess = false;
                        $('#Ntask' + middleid + 'Subject').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please select option<label>');
                        $('#Ntask' + middleid + 'Subject').focus();
                    }
                    if (NtaskPriority.trim() == '') {
                        validationsuccess = false;
                        $('#Ntask' + middleid + 'Priority').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please select option<label>');
                        $('#Ntask' + middleid + 'Priority').focus();
                    }
                    if (NtaskStatus.trim() == '') {
                        validationsuccess = false;
                        $('#Ntask' + middleid + 'Status').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please select option<label>');
                        $('#Ntask' + middleid + 'Status').focus();
                    }
                    if (NtaskComment.trim() == '') {
                        validationsuccess = false;
                        $('#Ntask' + middleid + 'Comment').parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#Ntask' + middleid + 'Comment').focus();
                    }
                    if (!validationsuccess) {
                        $('.Customoverlay').remove();
                        $('.Customloader').remove();
                        $event.preventDefault();
                        return false;
                    }
                    chrome.extension.sendRequest({
                            cmd: "bg_HttpGet_auth",
                            urlName: "CreateNewTask",
                            Query: {
                                searchcontactemail: Searchcontactemail,
                                searchaccountemail: Searchaccountemail,
                                assigned_to: NtaskAssignedTo,
                                Subject: NtaskSubject,
                                Priority: NtaskPriority,
                                Status: NtaskStatus,
                                Name: NtaskName,
                                Related_To: NtaskRelatedTo,
                                Comments: NtaskComment
                            }
                        },
                        function (data) {
                            var savedata = data;
                            $('.Customoverlay').remove();
                            $('.Customloader').remove();
                            try {
                                var data = JSON.parse(data);
                                var messagetobesend = data.message;
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(messagetobesend);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#Ntask' + middleid + 'AssignedTo').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                            catch (e) {
                                console.log("====E=====", e);
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(savedata);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#Ntask' + middleid + 'AssignedTo').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }

                        });

                }
                else if (formid == "MTNCase1" || formid == "MTNCase") {
                    var NCaseOwner = $('#NCase' + middleid + 'Owner').val();
                    var NCaseContactemail = $('#NCase' + middleid + 'Contactemail').val();
                    var NCaseContactType = $('#NCase' + middleid + 'ContactType').val();
                    var NCaseContact = $('#NCase' + middleid + 'Contact').val();
                    var NCaseAccountType = $('#NCase' + middleid + 'AccountType').val();
                    var NCaseAccount = $('#NCase' + middleid + 'Account').val();
                    var NCaseCasetype = $('#NCase' + middleid + 'Casetype').val();
                    var NCaseCasereason = $('#NCase' + middleid + 'Casereason').val();
                    var NCaseStatus = $('#NCase' + middleid + 'Status').val();
                    var NCasePriority = $('#NCase' + middleid + 'Priority').val();
                    var NCaseCaseorigin = $('#NCase' + middleid + 'Caseorigin').val();
                    var NCaseSubject = $('#NCase' + middleid + 'Subject').val();
                    var NCaseDescription = $('#NCase' + middleid + 'Description').val();
                    var Searchcontactemail = $('#NCase' + middleid + 'searchcontactemail').val();
                    var Searchaccountemail = $('#NCase' + middleid + 'searchaccountemail').val();
                    var validationsuccess = true;
                    if (NCaseContactemail.trim() == '') {
                        validationsuccess = false;
                        $('#NCase' + middleid + 'Contactemail').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NCase' + middleid + 'Contactemail').focus();
                    }
                    else {
                        if (!$scope.validateEmail(NCaseContactemail)) {
                            validationsuccess = false;
                            $('#NCase' + middleid + 'Contactemail').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please valid data<label>');
                            $('#NCase' + middleid + 'Contactemail').focus();
                        }
                    }
                    if (NCaseOwner.trim() == '') {
                        validationsuccess = false;
                        $('#NCase' + middleid + 'Owner').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NCase' + middleid + 'Owner').focus();
                    }
                    if (NCaseSubject.trim() == '') {
                        validationsuccess = false;
                        $('#NCase' + middleid + 'Subject').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 5%;">Please enter data<label>');
                        $('#NCase' + middleid + 'Subject').focus();
                    }
                    if (!validationsuccess) {
                        $('.Customoverlay').remove();
                        $('.Customloader').remove();
                        $event.preventDefault();
                        return false;
                    }
                    chrome.extension.sendRequest({
                            cmd: "bg_HttpGet_auth",
                            urlName: "CreateNewCase",
                            Query: {
                                searchcontactemail: Searchcontactemail,
                                searchaccountemail: Searchaccountemail,
                                owner: NCaseOwner,
                                contact: NCaseContact,
                                account: NCaseAccount,
                                case_type: NCaseCasetype,
                                case_reason: NCaseCasereason,
                                status: NCaseStatus,
                                priority: NCasePriority,
                                case_origin: NCaseCaseorigin,
                                form_subject: NCaseSubject,
                                description: NCaseDescription,
                                contact_email: NCaseContactemail
                            }// 'ram.gupta9964@gmail.com'
                        },
                        function (data) {
                            var savedata = data;
                            $('.Customoverlay').remove();
                            $('.Customloader').remove();
                            try {
                                var data = JSON.parse(data);
                                var messagetobesend = data.message;
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(messagetobesend);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#NCase' + middleid + 'Contactemail').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                            catch (e) {
                                console.log("====E=====", e);
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(savedata);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#NCase' + middleid + 'Contactemail').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                        });
                }
                else if (formid == "MTNLead1" || formid == "MTNLead") {
                    var NLeadAssignedTo = $('#NLead' + middleid + 'AssignedTo').val();
                    var NLeadSalutation = $('#NLead' + middleid + 'Salutation').val();
                    var NLeadFirstname = $('#NLead' + middleid + 'Firstname').val();
                    var NLeadLastname = $('#NLead' + middleid + 'Lastname').val();
                    var NLeadCompany = $('#NLead' + middleid + 'Company').val();
                    var NLeadTitle = $('#NLead' + middleid + 'Title').val();
                    var NLeadLeadsource = $('#NLead' + middleid + 'Leadsource').val();
                    var NLeadIndustry = $('#NLead' + middleid + 'Industry').val();
                    var NLeadAnnualrevenue = $('#NLead' + middleid + 'Annualrevenue').val();
                    var NLeadPhone = $('#NLead' + middleid + 'Phone').val();
                    var NLeadMobilephone = $('#NLead' + middleid + 'Mobilephone').val();
                    var NLeadFax = $('#NLead' + middleid + 'Fax').val();
                    var NLeadEmail = $('#NLead' + middleid + 'Email').val();
                    var NLeadWebsite = $('#NLead' + middleid + 'Website').val();
                    var NLeadStatus = $('#NLead' + middleid + 'Status').val();
                    var NLeadRating = $('#NLead' + middleid + 'Rating').val();
                    var NLeadDescription = $('#NLead' + middleid + 'Description').val();
                    var validationsuccess = true;
                    if (NLeadAssignedTo.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'AssignedTo').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'AssignedTo').focus();
                    }
                    if (NLeadFirstname.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Firstname').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Firstname').focus();
                    }
                    if (NLeadLastname.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Lastname').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Lastname').focus();
                    }
                    if (NLeadCompany.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Company').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Company').focus();
                    }
                    if (NLeadTitle.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Title').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Title').focus();
                    }
                    if (NLeadEmail.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Email').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Email').focus();
                    }
                    else {
                        if (!$scope.validateEmail(NLeadEmail)) {
                            validationsuccess = false;
                            $('#NLead' + middleid + 'Email').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please valid data<label>');
                            $('#NLead' + middleid + 'Email').focus();
                        }
                    }
                    if (NLeadStatus.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Status').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please select option<label>');
                        $('#NLead' + middleid + 'Status').focus();
                    }
                    if (NLeadAnnualrevenue.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Annualrevenue').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Annualrevenue').focus();
                    }
                    if (!validationsuccess) {
                        $('.Customoverlay').remove();
                        $('.Customloader').remove();
                        $event.preventDefault();
                        return false;
                    }
                    chrome.extension.sendRequest({
                            cmd: "bg_HttpGet_auth",
                            urlName: "CreateNewLead",
                            Query: {
                                assigned_to: NLeadAssignedTo,
                                salutaion: NLeadSalutation,
                                first_name: NLeadFirstname,
                                last_name: NLeadLastname,
                                company: NLeadCompany,
                                title: NLeadTitle,
                                lead_source: NLeadLeadsource,
                                industry: NLeadIndustry,
                                annual_revenue: NLeadAnnualrevenue,
                                phone: NLeadPhone,
                                mobile_phone: NLeadMobilephone,
                                fax: NLeadFax,
                                email: NLeadEmail,
                                website: NLeadWebsite,
                                status: NLeadStatus,
                                rating: NLeadRating,
                                description: NLeadDescription
                            }// 'ram.gupta9964@gmail.com'
                        },
                        function (data) {
                            var savedata = data;
                            $('.Customoverlay').remove();
                            $('.Customloader').remove();
                            try {
                                var data = JSON.parse(data);
                                var messagetobesend = data.message;
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(messagetobesend);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#NLead' + middleid + 'Firstname').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                            catch (e) {
                                console.log("====E=====", e);
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(savedata);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#NLead' + middleid + 'Firstname').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                        });
                }
                $event.preventDefault();
                return false;
            }
            $scope.MTSearch = function (id, constrainID) {
                var stringToSearch = $('#' + id).val();
                var inputtofileid = "#" + id;
                var costrain = $('#' + constrainID).val();
                var formid;
                if (stringToSearch.trim() == "") {
                    $('#' + id).css('border-color', "red");
                    return false;
                }
                if (id == "NtaskName" || id == "NtaskRelatedTo") {
                    formid = "MTNTask";
                }
                else if (id == "Ntask1Name" || id == "Ntask1RelatedTo") {
                    formid = "MTNTask1";
                }
                else if (id == "NCase1Contact" || id == "NCase1Account") {
                    formid = "MTNCase1";
                }
                else if (id == "NCaseContact" || id == "NCaseAccount") {
                    formid = "MTNCase";
                }
                $('.Customoverlay').remove();
                $('.Customloader').remove();
                $('#' + formid).parent().parent().append(Loaderhtmldefault);
                $('.Customoverlay').show();
                $('.Customloader').show();
                var myArraySplit = stringToSearch.split(' ');
                var FirstName = myArraySplit[0];
                var LastName = myArraySplit[1];
                if (typeof LastName == "undefined") {
                    LastName = "";
                }
                chrome.extension.sendRequest({
                    cmd: "bg_HttpGet_auth",
                    urlName: "SearchCase",
                    Query: {first_name: FirstName, last_name: LastName, constrain: costrain}// 'ram.gupta9964@gmail.com'
                }, function (data) {
                    var data = JSON.parse(data);
                    var PopupHtml = "";
                    var Checked = "";
                    if (data.Number_of_records > 0) {

                        if (typeof data.contactdata != "undefined") {

                            angular.forEach(data.contactdata, function (item, key) {
                                var gotname = item.FirstName + " " + item.LastName;
                                var gotEmail = item.Email;
                                if (key == 0) {
                                    Checked = "checked";
                                }
                                else {
                                    Checked = "";
                                }
                                PopupHtml += '<label class="containerradio">' + gotname + '<input type="radio" ' + Checked + ' name="searchedName" value="' + gotname + '___' + gotEmail + '"><span class="checkmark"></span><br><label class="radiolabel">' + gotEmail + '</label></label>';
                                //PopupHtml="<p id='searchedName'>"+gotname+"</p><p>"+gotEmail+"</p><input type='hidden' id='searchedinput' value='"+stringToSearch+"'";
                            });

                        }
                        else if (typeof data.accountdata != "undefined") {
                            angular.forEach(data.accountdata, function (item, key) {
                                var gotname = item.Name;
                                var gotEmail = item.Email;
                                if (key == 0) {
                                    Checked = "checked";
                                }
                                else {
                                    Checked = "";
                                }
                                PopupHtml += '<label class="containerradio">' + gotname + '<input type="radio" ' + Checked + ' name="searchedName" value="' + gotname + '___' + gotEmail + '"><span class="checkmark"></span><br><label class="radiolabel">' + gotEmail + '</label></label>';
                            });
                            //PopupHtml="<p id='searchedName'>"+gotname+"</p><p>"+gotEmail+"</p>";
                        }
                        else {
                            PopupHtml = "<p id='searchedNameError'>Unexpected Response From Api</p>";
                        }

                    }
                    else if (data.Number_of_records == 0) {
                        PopupHtml = "<p id='searchedNameError'>No Records Found</p>";
                    }
                    else {
                        PopupHtml = "<p id='searchedNameError'>Unexpected Response From Api</p>";
                    }
                    PopupHtml += "<input type='hidden' id='searchedinput' value='" + inputtofileid + "'>";
                    $('.Customoverlay').remove();
                    $('.Customloader').remove()
                    $('#CustomPopup').find('.dialogPopup-msg').html(PopupHtml);
                    $('#CustomPopup').show();

                });

            }
            $scope.onChangeFunction = function (id) {
                var inner = "";
                //console.log($('#'+id).val());
                var previous = $('#' + id).val();
                var f = setInterval(function () {
                    if (previous != $('#' + id).val() || $('#' + id).val() == "") {
                        if (previous != $('#' + id).val()) {
                            clearInterval(f);
                        }
                        if (id == "MTSelectIn") {
                            inner = "1";
                        }
                        if ($('#' + id).val() == "Ntask") {
                            $('.NTaskContainer').hide();
                            $('#NTaskHtml' + inner).show();
                            $('.openCasePageToBeHidden').hide();
                            $('.showOpenCaseClass').hide();
                        }
                        else if ($('#' + id).val() == "Ncase") {
                            $('.NTaskContainer').hide();
                            $('#NCaseHtml' + inner).show();
                            $('.openCasePageToBeHidden').hide();
                            $('.showOpenCaseClass').hide();
                        }
                        else if ($('#' + id).val() == "Nlead") {
                            $('.NTaskContainer').hide();
                            $('#NLeadHtml' + inner).show();
                            $('.openCasePageToBeHidden').hide();
                            $('.showOpenCaseClass').hide();
                        }
                        else {
                            $('.NTaskContainer').hide();
                            $('.openCasePageToBeHidden').show();
                            $('.showOpenCaseClass').show();
                        }
                    }
                }, 100);

            }

            $scope.numberOfPages = function () {
                var pageno = ($filter('filter')($scope.DisplayCase.total_open_case_data, $scope.searchText)).length / $scope.pageSize;
                if (pageno == 0) {
                    pageno++;
                }
                return Math.ceil(pageno);
            }
            $scope.numberOfItems = function () {
                return ($filter('filter')($scope.DisplayCase.total_open_case_data, $scope.searchText)).length;
            }

            $scope.numberOfPagesforclose = function () {
                var pageno = ($filter('filter')($scope.DisplayCase.close_case_data, $scope.searchText)).length / $scope.pageSize;
                if (pageno == 0) {
                    pageno++;
                }
                return Math.ceil(pageno);
            }
            $scope.numberOfItemsforclose = function () {
                return ($filter('filter')($scope.DisplayCase.close_case_data, $scope.searchText)).length;
            }
            $scope.numberOfPagesforauto = function () {
                var pageno = ($filter('filter')($scope.DisplayCase.total_autoreplied_data, $scope.searchText)).length / $scope.pageSize;
                if (pageno == 0) {
                    pageno++;
                }
                return Math.ceil(pageno);
            }
            $scope.numberOfItemsforauto = function () {
                return ($filter('filter')($scope.DisplayCase.total_autoreplied_data, $scope.searchText)).length;
            }
            $scope.AlertIt = function () {
                var w = window.open('about:blank', 'Popup_Window', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=300,left = 312,top = 234');
                this.target = 'Popup_Window';
            }

            chrome.extension.sendRequest({
                cmd: "bg_HttpGet", urlName: "DisplayAutoReply", Query: {
                    rm_email: $rootScope.CurrentLoginGmailUser.Email//'ram.gupta9964@gmail.com'
                }
            }, function (data) {
                if (data) {
                    $scope.AutoReplied = JSON.parse(data).auto_replied;
                    $scope.$apply();
                }
            });

            chrome.extension.sendRequest({
                cmd: "bg_HttpGet", urlName: "SentimentServlet", Query: {
                    email: $rootScope.CurrentLoginGmailUser.Email
                    //  email: 'ram.gupta9964@gmail.com'
                }
            }, function (data) {
                if (data) {
                    obj = JSON.parse(data);
                    // alert(JSON.stringify(data));
                    for (var i = 0; i < obj.data.length; i++) {
                        if (obj.data[i].sentiment === "positive")      //Sentiment_Output
                        {
                            $scope.Positive++;
                        }
                        else if (obj.data[i].sentiment === "negative")     //Sentiment_Output
                        {
                            $scope.Negative++;
                        }
                        else {
                            $scope.Neutral++;
                        }
                    }


                    // alert(Positive);
                    // angular.forEach(data, function (item, key) {
                    //     switch (item.Sentiment_Output.toLowerCase()) {
                    //         case "positive":
                    //             {
                    //                 $scope.Positive++;
                    //             }
                    //             break;
                    //         case "negative":
                    //             {
                    //                 $scope.Negative++;
                    //             }
                    //             break;
                    //         default:
                    //             {
                    //                 $scope.Neutral++;
                    //             }
                    //     }
                    // });
                    $scope.$apply();
                }
            });
        });

        myApp.controller('InfoController', function ($scope, $rootScope) {

            $scope.InfoUserEmail = '';
            $scope.InfoUserName = '';
            $scope.EmailSubject;
            $scope.EmailBody;
            $scope.ShowCasePanel = true;
            $scope.opencasecolor = {
                "background-color": "#90EE90 "
            };
            $scope.myObj = {
                "background-color": "#f39090"
            };
            var Loaderhtmldefault = '<div class="Customoverlay" id="Customoverlay1"></div><div class="Customloader" id="Customloader1"></div>';

            sdk.Conversations.registerThreadViewHandler(function (ThreadView) {
                ThreadView.on('contactHover', function (data) {
                    $scope.InfoUserEmail = data.contact.emailAddress;
                    $scope.$apply();
                });
                $scope.EmailSubject = ThreadView.getSubject();
                $scope.$apply();
            });

            sdk.Conversations.registerMessageViewHandler(function (MessageView) {
                $scope.InfoUserEmail = MessageView.getSender().emailAddress;
                $scope.InfoUserName = MessageView.getSender().name;
                var element = MessageView.getBodyElement();
                $scope.EmailBody = $(element).text();
                $scope.$apply();
            });
            $scope.validateEmail = function (email) {
                var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return re.test(email);
            }
            $scope.ShowAllTasks = function () {
                $('.Customoverlay').remove();
                $('.Customloader').remove();
                $('.appendlowloader').append(Loaderhtmldefault);
                $('.Customoverlay').show();
                $('.Customloader').show()
                chrome.extension.sendRequest({
                        cmd: "bg_HttpGet_auth", urlName: "DisplayAllTasks", Query: {rm_email: $scope.InfoUserEmail}// 'ram.gupta9964@gmail.com'
                    },
                    function (data) {
                        $('.Customoverlay').remove();
                        $('.Customloader').remove();
                        try {
                            var data = JSON.parse(data);
                            if (data.Number_of_records <= 0) {
                                $('.alltasksbody').html('<label>No Tasks Found</label>');
                                $('.alltasksmain').show();
                            }
                            else {
                                var htmldataf = '';
                                angular.forEach(data.taskdata, function (item, key) {
                                    var Subject = item.Subject;
                                    var Name = $scope.InfoUserName;
                                    var DueDate = item.DueDate;
                                    var Status = item.Status;
                                    var Priority = item.Priority;
                                    htmldataf += '<div><div><label>Subject:</label><a href="javascript:void(0)"><b class="ng-binding">' + Subject + '</b></a></div><div class="ng-binding"><label>Name:</label>' + Name + '</div><div class="ng-binding"><label>DueDate:</label>' + DueDate + '&nbsp&nbsp&nbsp<label>Status:</label>' + Status + '</div><div class="ng-binding"><label>Priority:</label>' + Priority + '</div></div><hr class="ht-sm">';
                                    //htmldataf+='<div><div><label>Subject:</label><a href="javascript:void(0)"><b class="ng-binding">'+Subject+'</b></a></div><div class="ng-binding"><label>Name:</label>'+Name+'</div><div class="ng-binding"><label>DueDate:</label>'+DueDate+'<label>Status:</label>'+Status+'</div><div class="ng-binding"><label>Priority:</label>'+Priority+'</div></div>';                                                                        '
                                });
                                $('.alltasksbody').html(htmldataf);
                                $('.alltasksmain').show();
                            }
                            $('.allcasestohide').hide();
                        }
                        catch (e) {
                            console.log("====E=====", e);
                            alert("Unknown Response. Please Try Again.");
                        }

                    });
            }
            $scope.GoBack = function () {
                $('.allcasestohide').show();
                $('.alltasksmain').hide();
            }
            $scope.SearchPopupCall = function (type) {
                $('.CustomPopup').hide();
                if (type == "OK") {
                    if (typeof $('#searchedNameError').html() == "undefined") {
                        var actualnameandemail = $("input[name='searchedName']:checked").val().split('___');
                        var actualname = actualnameandemail[0];
                        var actualemail = actualnameandemail[1];
                        var actualid = $('#searchedinput').val();
                    }
                    else {
                        var actualname = $('#searchedNameError').html();
                        var actualid = $('#searchedinput').val();
                    }
                    if (actualname.trim() !== "Unexpected Response From Api" && actualname.trim() !== "No Records Found") {

                        var begning = actualid.replace("Name", "");
                        begning = begning.replace("RelatedTo", "");
                        begning = begning.replace("Contact", "");
                        begning = begning.replace("Account", "");
                        if (actualid.includes('Name') || actualid.includes('Contact')) {
                            $(begning + "searchcontactemail").val(actualemail);
                        }
                        else {
                            $(begning + "searchaccountemail").val(actualemail);
                        }
                        $(actualid).val(actualname);
                    }
                }
                if (type == "OKNEW") {
                    location.reload();
                    $('.showOpenCaseClass').show();
                    $('.NTaskContainer').hide();
                }
                if (type == "OKNEWLOW") {
                    location.reload();
                    $('.NTaskContainer').hide();
                    $('.showOpenCaseClass').show();
                    $('.allcasestohide').show();
                }

            }
            $scope.ClearForm = function (formid) {
                $scope.onChangeFunction('MTSelectIn');
                $('#MTSelectIn option:selected').removeAttr('selected');
                $("#MTSelectIn option[value='']").attr('selected', 'selected');

            }
            $scope.SaveForm = function (formid, $event) {
                $('.Customoverlay').remove();
                $('.Customloader').remove();
                $('.positionabsolute').hide();
                $('.customerrorfields').remove();
                $('#' + formid).parent().parent().append(Loaderhtmldefault);
                $('.Customoverlay').show();
                $('.Customloader').show();
                var middleid = "";
                if (formid == "MTNTask1" || formid == "MTNCase1" || formid == "MTNLead1") {
                    middleid = "1";
                }
                if (formid == "MTNTask1" || formid == "MTNTask") {
                    var NtaskAssignedTo = $('#Ntask' + middleid + 'AssignedTo').val();
                    var NtaskSubject = $('#Ntask' + middleid + 'Subject').val();
                    var NtaskPriority = $('#Ntask' + middleid + 'Priority').val();
                    var NtaskStatus = $('#Ntask' + middleid + 'Status').val();
                    var NtaskNameType = $('#Ntask' + middleid + 'NameType').val();
                    var NtaskName = $('#Ntask' + middleid + 'Name').val();
                    var NtaskRelatedToType = $('#Ntask' + middleid + 'RelatedToType').val();
                    var NtaskRelatedTo = $('#Ntask' + middleid + 'RelatedTo').val();
                    var NtaskComment = $('#Ntask' + middleid + 'Comment').val();
                    var Searchcontactemail = $('#Ntask' + middleid + 'searchcontactemail').val();
                    var Searchaccountemail = $('#Ntask' + middleid + 'searchaccountemail').val();
                    var validationsuccess = true;
                    if (NtaskSubject.trim() == '') {
                        validationsuccess = false;
                        $('#Ntask' + middleid + 'Subject').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please select option<label>');
                        $('#Ntask' + middleid + 'Subject').focus();
                    }
                    if (NtaskPriority.trim() == '') {
                        validationsuccess = false;
                        $('#Ntask' + middleid + 'Priority').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please select option<label>');
                        $('#Ntask' + middleid + 'Priority').focus();
                    }
                    if (NtaskStatus.trim() == '') {
                        validationsuccess = false;
                        $('#Ntask' + middleid + 'Status').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please select option<label>');
                        $('#Ntask' + middleid + 'Priority').focus();
                    }
                    if (NtaskComment.trim() == '') {
                        validationsuccess = false;
                        $('#Ntask' + middleid + 'Comment').parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#Ntask' + middleid + 'Comment').focus();
                    }
                    if (!validationsuccess) {
                        $('.Customoverlay').remove();
                        $('.Customloader').remove();
                        $event.preventDefault();
                        return false;
                    }
                    chrome.extension.sendRequest({
                            cmd: "bg_HttpGet_auth",
                            urlName: "CreateNewTask",
                            Query: {
                                searchcontactemail: Searchcontactemail,
                                searchaccountemail: Searchaccountemail,
                                assigned_to: NtaskAssignedTo,
                                Subject: NtaskSubject,
                                Priority: NtaskPriority,
                                Status: NtaskStatus,
                                Name: NtaskName,
                                Related_To: NtaskRelatedTo,
                                Comments: NtaskComment
                            }
                        },
                        function (data) {
                            var savedata = data;
                            $('.Customoverlay').remove();
                            $('.Customloader').remove();
                            try {
                                var data = JSON.parse(data);
                                var messagetobesend = data.message;
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(messagetobesend);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#Ntask' + middleid + 'AssignedTo').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                            catch (e) {
                                console.log("====E=====", e);
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(savedata);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#Ntask' + middleid + 'AssignedTo').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }

                        });

                }
                else if (formid == "MTNCase1" || formid == "MTNCase") {
                    var NCaseOwner = $('#NCase' + middleid + 'Owner').val();
                    var NCaseContactemail = $('#NCase' + middleid + 'Contactemail').val();
                    var NCaseContactType = $('#NCase' + middleid + 'ContactType').val();
                    var NCaseContact = $('#NCase' + middleid + 'Contact').val();
                    var NCaseAccountType = $('#NCase' + middleid + 'AccountType').val();
                    var NCaseAccount = $('#NCase' + middleid + 'Account').val();
                    var NCaseCasetype = $('#NCase' + middleid + 'Casetype').val();
                    var NCaseCasereason = $('#NCase' + middleid + 'Casereason').val();
                    var NCaseStatus = $('#NCase' + middleid + 'Status').val();
                    var NCasePriority = $('#NCase' + middleid + 'Priority').val();
                    var NCaseCaseorigin = $('#NCase' + middleid + 'Caseorigin').val();
                    var NCaseSubject = $('#NCase' + middleid + 'Subject').val();
                    var NCaseDescription = $('#NCase' + middleid + 'Description').val();
                    var Searchcontactemail = $('#NCase' + middleid + 'searchcontactemail').val();
                    var Searchaccountemail = $('#NCase' + middleid + 'searchaccountemail').val();
                    var validationsuccess = true;
                    if (NCaseContactemail.trim() != '')

                        if (NCaseContactemail.trim() == '') {
                            validationsuccess = false;
                            $('#NCase' + middleid + 'Contactemail').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                            $('#NCase' + middleid + 'Contactemail').focus();
                        }
                        else {
                            if (!$scope.validateEmail(NCaseContactemail)) {
                                validationsuccess = false;
                                $('#NCase' + middleid + 'Contactemail').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please valid data<label>');
                                $('#NCase' + middleid + 'Contactemail').focus();
                            }
                        }
                    if (NCaseOwner.trim() == '') {
                        validationsuccess = false;
                        $('#NCase' + middleid + 'Owner').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NCase' + middleid + 'Owner').focus()
                    }
                    if (NCaseSubject.trim() == '') {
                        validationsuccess = false;
                        $('#NCase' + middleid + 'Subject').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 5%;">Please enter data<label>');
                        $('#NCase' + middleid + 'Subject').focus();
                    }
                    if (!validationsuccess) {
                        $('.Customoverlay').remove();
                        $('.Customloader').remove();
                        $event.preventDefault();
                        return false;
                    }
                    chrome.extension.sendRequest({
                            cmd: "bg_HttpGet_auth",
                            urlName: "CreateNewCase",
                            Query: {
                                searchcontactemail: Searchcontactemail,
                                searchaccountemail: Searchaccountemail,
                                owner: NCaseOwner,
                                contact: NCaseContact,
                                account: NCaseAccount,
                                case_type: NCaseCasetype,
                                case_reason: NCaseCasereason,
                                status: NCaseStatus,
                                priority: NCasePriority,
                                case_origin: NCaseCaseorigin,
                                form_subject: NCaseSubject,
                                description: NCaseDescription,
                                contact_email: NCaseContactemail
                            }// 'ram.gupta9964@gmail.com'
                        },
                        function (data) {
                            var savedata = data;
                            $('.Customoverlay').remove();
                            $('.Customloader').remove();
                            try {
                                var data = JSON.parse(data);
                                var messagetobesend = data.message;
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(messagetobesend);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#NCase' + middleid + 'Contactemail').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                            catch (e) {
                                console.log("====E=====", e);
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(savedata);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#NCase' + middleid + 'Contactemail').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                        });
                }
                else if (formid == "MTNLead1" || formid == "MTNLead") {
                    var NLeadAssignedTo = $('#NLead' + middleid + 'AssignedTo').val();
                    var NLeadSalutation = $('#NLead' + middleid + 'Salutation').val();
                    var NLeadFirstname = $('#NLead' + middleid + 'Firstname').val();
                    var NLeadLastname = $('#NLead' + middleid + 'Lastname').val();
                    var NLeadCompany = $('#NLead' + middleid + 'Company').val();
                    var NLeadTitle = $('#NLead' + middleid + 'Title').val();
                    var NLeadLeadsource = $('#NLead' + middleid + 'Leadsource').val();
                    var NLeadIndustry = $('#NLead' + middleid + 'Industry').val();
                    var NLeadAnnualrevenue = $('#NLead' + middleid + 'Annualrevenue').val();
                    var NLeadPhone = $('#NLead' + middleid + 'Phone').val();
                    var NLeadMobilephone = $('#NLead' + middleid + 'Mobilephone').val();
                    var NLeadFax = $('#NLead' + middleid + 'Fax').val();
                    var NLeadEmail = $('#NLead' + middleid + 'Email').val();
                    var NLeadWebsite = $('#NLead' + middleid + 'Website').val();
                    var NLeadStatus = $('#NLead' + middleid + 'Status').val();
                    var NLeadRating = $('#NLead' + middleid + 'Rating').val();
                    var NLeadDescription = $('#NLead' + middleid + 'Description').val();
                    var validationsuccess = true;
                    if (NLeadAssignedTo.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'AssignedTo').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Firstname').focus();
                    }
                    if (NLeadFirstname.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Firstname').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Firstname').focus();
                    }
                    if (NLeadLastname.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Lastname').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Lastname').focus();
                    }
                    if (NLeadCompany.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Company').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');

                    }
                    if (NLeadTitle.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Title').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Title').focus();
                    }
                    if (NLeadEmail.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Email').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Email').focus();
                    }
                    else {
                        if (!$scope.validateEmail(NLeadEmail)) {
                            validationsuccess = false;
                            $('#NLead' + middleid + 'Email').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please valid data<label>');
                            $('#NLead' + middleid + 'Email').focus();
                        }
                    }
                    if (NLeadStatus.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Status').parent().parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please select option<label>');
                        $('#NLead' + middleid + 'Status').focus();
                    }
                    if (NLeadAnnualrevenue.trim() == '') {
                        validationsuccess = false;
                        $('#NLead' + middleid + 'Annualrevenue').parent().parent().append('<label class="customerrorfields" style="font-weight: 100;color: red;margin-left: 2%;">Please enter data<label>');
                        $('#NLead' + middleid + 'Annualrevenue').focus();
                    }
                    if (!validationsuccess) {
                        $('.Customoverlay').remove();
                        $('.Customloader').remove();
                        $event.preventDefault();
                        return false;
                    }
                    chrome.extension.sendRequest({
                            cmd: "bg_HttpGet_auth",
                            urlName: "CreateNewLead",
                            Query: {
                                assigned_to: NLeadAssignedTo,
                                salutaion: NLeadSalutation,
                                first_name: NLeadFirstname,
                                last_name: NLeadLastname,
                                company: NLeadCompany,
                                title: NLeadTitle,
                                lead_source: NLeadLeadsource,
                                industry: NLeadIndustry,
                                annual_revenue: NLeadAnnualrevenue,
                                phone: NLeadPhone,
                                mobile_phone: NLeadMobilephone,
                                fax: NLeadFax,
                                email: NLeadEmail,
                                website: NLeadWebsite,
                                status: NLeadStatus,
                                rating: NLeadRating,
                                description: NLeadDescription
                            }// 'ram.gupta9964@gmail.com'
                        },
                        function (data) {
                            var savedata = data;
                            $('.Customoverlay').remove();
                            $('.Customloader').remove();
                            try {
                                var data = JSON.parse(data);
                                var messagetobesend = data.message;
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(messagetobesend);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#NLead' + middleid + 'Firstname').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                            catch (e) {
                                console.log("====E=====", e);
                                $('#' + formid).parent().parent().find('.positionabsolute').find('p').html(savedata);
                                $('#' + formid).parent().parent().find('.positionabsolute').show();
                                $('#NLead' + middleid + 'Firstname').focus();
                                setTimeout(function () {
                                    location.reload();
                                }, 5000);
                            }
                        });
                }
                $event.preventDefault();
                return false;
            }
            $scope.MTSearch = function (id, constrainID) {

                var stringToSearch = $('#' + id).val();
                var inputtofileid = "#" + id;
                var costrain = $('#' + constrainID).val();
                if (stringToSearch.trim() == "") {
                    $('#' + id).css('border-color', "red");
                    return false;
                }
                if (id == "NtaskName" || id == "NtaskRelatedTo") {
                    formid = "MTNTask";
                }
                else if (id == "Ntask1Name" || id == "Ntask1RelatedTo") {
                    formid = "MTNTask1";
                }
                else if (id == "NCase1Contact" || id == "NCase1Account") {
                    formid = "MTNCase1";
                }
                else if (id == "NCaseContact" || id == "NCaseAccount") {
                    formid = "MTNCase";
                }
                $('.Customoverlay').remove();
                $('.Customloader').remove();
                $('#' + formid).parent().parent().append(Loaderhtmldefault);
                $('.Customoverlay').show();
                $('.Customloader').show();
                var myArraySplit = stringToSearch.split(' ');
                var FirstName = myArraySplit[0];
                var LastName = myArraySplit[1];
                if (typeof LastName == "undefined") {
                    LastName = "";
                }
                chrome.extension.sendRequest({
                    cmd: "bg_HttpGet_auth",
                    urlName: "SearchCase",
                    Query: {first_name: FirstName, last_name: LastName, constrain: costrain}// 'ram.gupta9964@gmail.com'
                }, function (data) {
                    var data = JSON.parse(data);
                    var PopupHtml = "";
                    var Checked = "";
                    if (data.Number_of_records > 0) {

                        if (typeof data.contactdata != "undefined") {

                            angular.forEach(data.contactdata, function (item, key) {
                                var gotname = item.FirstName + " " + item.LastName;
                                var gotEmail = item.Email;
                                if (key == 0) {
                                    Checked = "checked";
                                }
                                else {
                                    Checked = "";
                                }
                                PopupHtml += '<label class="containerradio">' + gotname + '<input type="radio" ' + Checked + ' name="searchedName" value="' + gotname + '___' + gotEmail + '"><span class="checkmark"></span><br><label class="radiolabel">' + gotEmail + '</label></label>';
                                //PopupHtml="<p id='searchedName'>"+gotname+"</p><p>"+gotEmail+"</p><input type='hidden' id='searchedinput' value='"+stringToSearch+"'";
                            });

                        }
                        else if (typeof data.accountdata != "undefined") {
                            angular.forEach(data.accountdata, function (item, key) {
                                var gotname = item.Name;
                                var gotEmail = item.Email;
                                if (key == 0) {
                                    Checked = "checked";
                                }
                                else {
                                    Checked = "";
                                }
                                PopupHtml += '<label class="containerradio">' + gotname + '<input type="radio" ' + Checked + ' name="searchedName" value="' + gotname + '___' + gotEmail + '"><span class="checkmark"></span><br><label class="radiolabel">' + gotEmail + '</label></label>';
                            });
                            //PopupHtml="<p id='searchedName'>"+gotname+"</p><p>"+gotEmail+"</p>";
                        }
                        else {
                            PopupHtml = "<p>Unexpected Response From Api</p>";
                        }

                    }
                    else if (data.Number_of_records == 0) {
                        PopupHtml = "<p>No Records Found</p>";
                    }
                    else {
                        PopupHtml = "<p>Unexpected Response From Api</p>";
                    }
                    PopupHtml += "<input type='hidden' id='searchedinput' value='" + inputtofileid + "'>";
                    $('.Customoverlay').remove();
                    $('.Customloader').remove()
                    $('#CustomPopup1').find('.dialogPopup-msg').html(PopupHtml);
                    $('#CustomPopup1').show();

                });

            }
            $scope.onChangeFunction = function (id) {
                var inner = "";
                var previous = $('#' + id).val();
                var f = setInterval(function () {
                    if (previous != $('#' + id).val() || $('#' + id).val() == "") {
                        if (previous != $('#' + id).val()) {
                            clearInterval(f);
                        }
                        if (id == "MTSelectIn") {
                            inner = "1";
                        }
                        if ($('#' + id).val() == "Ntask") {
                            $('.NTaskContainer').hide();
                            $('#NTaskHtml' + inner).show();
                            $('.openCasePageToBeHidden').hide();
                            $('.showOpenCaseClass').hide();
                            $('.allcasestohide').hide();
                        }
                        else if ($('#' + id).val() == "Ncase") {
                            $('.NTaskContainer').hide();
                            $('#NCaseHtml' + inner).show();
                            $('.openCasePageToBeHidden').hide();
                            $('.showOpenCaseClass').hide();
                            $('.allcasestohide').hide();
                        }
                        else if ($('#' + id).val() == "Nlead") {
                            $('.NTaskContainer').hide();
                            $('#NLeadHtml' + inner).show();
                            $('.openCasePageToBeHidden').hide();
                            $('.showOpenCaseClass').hide();
                            $('.allcasestohide').hide();
                        }
                        else {
                            $('.NTaskContainer').hide();
                            $('.openCasePageToBeHidden').show();
                            $('.showOpenCaseClass').show();
                            $('.allcasestohide').show();
                        }
                    }
                }, 100);
                /*if(id=="MTSelectIn")
				{
					inner="1";
				}

				if($('#'+id).val()=="Ntask")
				{
					$('.showOpenCaseClass').hide();
					$('.NTaskContainer').hide();
					$('#NTaskHtml'+inner).show();
					$('.allcasestohide').hide();
				}
				else if($('#'+id).val()=="Ncase")
				{
					$('.showOpenCaseClass').hide();
					$('.NTaskContainer').hide();
					$('#NCaseHtml'+inner).show();
					$('.allcasestohide').hide();
				}
				else if($('#'+id).val()=="Nlead")
				{
					$('.showOpenCaseClass').hide();
					$('.NTaskContainer').hide();
					$('#NLeadHtml'+inner).show();
					$('.allcasestohide').hide();
				}
				else
				{
					$('.NTaskContainer').hide();
					$('.showOpenCaseClass').show();
					$('.allcasestohide').show();
				}*/

            }
            $scope.SignOut = function () {
                chrome.extension.sendRequest({
                    cmd: "bg_signout"
                }, function (data) {
                    $rootScope.currentPage = 'login';
                    $rootScope.$apply();
                });
            }
            $scope.$watch('InfoUserEmail', function (newValue, oldValue) {
                if (newValue && newValue != oldValue)
                    $scope.GetProfile(newValue);
            });

            $scope.GetProfile = function (email) {
                //$rootScope.ShowSpinner = true;

                //TODO remove this line.
                //email = "ram.gupta9964@gmail.com";

                //get case or lead
                chrome.extension.sendRequest({
                    cmd: "bg_HttpGet_auth", urlName: "SummerizerServlet", Query: {
                        email: email, subject: $scope.EmailSubject,
                        summ_txt: $scope.EmailBody
                    }
                }, function (data) {
                    // alert($scope.EmailSubject);
                    // alert("body"+$scope.EmailBody);
                    var allData = JSON.parse(data);
                    ;
                    $scope.CaseLeadData = allData;
                    $scope.ShowCasePanel = true;
                    //if typoe is "lead" or "no case no lead" hide case panel.
                    if (allData.type.toLowerCase() == "lead" || allData.type.toLowerCase() == "no case no lead") {
                        $scope.ShowCasePanel = false;
                    }
                    $scope.$apply();
                });

                //get gmail profile
                chrome.extension.sendRequest({
                    cmd: "bg_HttpGet", urlName: "GetGmailProfile", Query: {
                        p_email: email
                    }
                }, function (data) {
                    if (data) {
                        $scope.GmailProfile = JSON.parse(data);
                        $scope.$apply();
                    }
                });

                chrome.extension.sendRequest({
                    cmd: "bg_HttpGet", urlName: "GetSocialProfile", Query: {
                        email: email
                        //   email: 'rohit.varma0090@gmail.com'
                    }
                }, function (data) {
                    if (data != "null") {
                        var profile = JSON.parse(data);
                        var SocialProfiles = profile.person.urls;
                        $.each(SocialProfiles, function (name, item) {
                            switch (item['@name']) {
                                case "Google Profiles": {
                                    item.HasIcon = true;
                                    item.IconName = "fa fa-google-plus-square";
                                    item.Color = "#DD5044";
                                }
                                    break;
                                case "LinkedIn": {
                                    item.HasIcon = true;
                                    item.IconName = "fa fa-linkedin-square";
                                    item.Color = "#007BB6";
                                }
                                    break;
                                case "Twitter": {
                                    item.HasIcon = true;
                                    item.IconName = "fa fa-twitter-square";
                                    item.Color = "#1EA1F3";
                                }
                                    break;
                                case "Facebook": {
                                    item.HasIcon = true;
                                    item.IconName = "fa fa-facebook-square";
                                    item.Color = "#3B5998";
                                }
                                    break;
                                case "Pinterest": {
                                    item.HasIcon = true;
                                    item.IconName = "fa fa-pinterest-square";
                                    item.Color = "#CC2028";
                                }
                                    break;
                                case "Instagram": {
                                    item.HasIcon = true;
                                    item.IconName = "fa fa-instagram";
                                    item.Color = "#FCAC4F";
                                }
                                    break;
                                default: {
                                    item.HasIcon = false;
                                }
                            }
                        });
                        $scope.SocialProfiles = SocialProfiles;
                        $scope.$apply();
                    }
                });

                //get social profile
                //chrome.extension.sendRequest({
                //    cmd: "bg_HttpGet", urlName: "SocialProfile", Query: {
                //        p_email: email
                //    }
                //}, function (data) {
                //    if (data != "null") {
                //        var profile = JSON.parse(data);
                //        var SocialProfiles = profile.socialProfiles;
                //        $scope.Demographics = profile.demographics;
                //        $.each(SocialProfiles, function (name, item) {
                //            switch (item.typeName) {
                //                case "GooglePlus":
                //                    {
                //                        item.HasIcon = true;
                //                        item.IconName = "fa fa-google-plus-square";
                //                        item.Color = "#DD5044";
                //                    }
                //                    break;
                //                case "LinkedIn":
                //                    {
                //                        item.HasIcon = true;
                //                        item.IconName = "fa fa-linkedin-square";
                //                        item.Color = "#007BB6";
                //                    }
                //                    break;
                //                case "Twitter":
                //                    {
                //                        item.HasIcon = true;
                //                        item.IconName = "fa fa-twitter-square";
                //                        item.Color = "#1EA1F3";
                //                    }
                //                    break;
                //                case "Facebook":
                //                    {
                //                        item.HasIcon = true;
                //                        item.IconName = "fa fa-facebook-square";
                //                        item.Color = "#3B5998";
                //                    }
                //                    break;
                //                default:
                //                    {
                //                        item.HasIcon = false;
                //                    }
                //            }
                //        });
                //        $scope.SocialProfiles = SocialProfiles;
                //        $scope.$apply();
                //    }
                //});

                //get email tempate.
                chrome.extension.sendRequest({
                    cmd: "bg_HttpGet", urlName: "GetEmailTemplate", Query: {
                        email: email
                    }
                }, function (data) {
                    if (data) {
                        var emailData = JSON.parse(data);
                        if (emailData && emailData.data) {
                            angular.forEach(emailData.data, function (item, key) {
                                item.id = key;
                            });
                            $rootScope.EmailTempateList = emailData.data;
                            $rootScope.$apply();
                        } else {
                            $rootScope.EmailTempateList = [];
                            $rootScope.$apply();
                        }
                    }
                });

                //mail data.
                chrome.extension.sendRequest({
                    cmd: "bg_HttpGet", urlName: "MailDataBased",
                    Query: {
                        email: email, to: $rootScope.CurrentLoginGmailUser.Email

                        //email: 'khushbumehta102@gmail.com'
                    }//'ram.gupta9964@gmail.com'
                }, function (data) {
                    if (data) {
                        $scope.EmailData = JSON.parse(data);
                        // alert("EmailData:::"+EmailData.casedata.length);
                        $scope.$apply();
                    }
                });

                $scope.DisplayCaseBasedOnEmail(email);
            }

            $scope.DisplayCaseBasedOnEmail = function (email) {
                //TODO remove this line
                //  email = 'khushbumehta102@gmail.com';
                chrome.extension.sendRequest({
                    //rm_email= 'ram.gupta9964@gmail.com'
                    //email ='khushbumehta102@gmail.com'
                    cmd: "bg_HttpGet_auth",
                    urlName: "DisplayCaseBasedOnEmail",
                    Query: {
                        rm_email: $rootScope.CurrentLoginGmailUser.Email,
                        email: email,
                        subject: $scope.EmailSubject
                    }
                }, function (data) {
                    if (data) {
                        $scope.opencasecount = 0;
                        $scope.closecasecount = 0;

                        //alert("Display case based on email"+data);
                        //  alert("subject:::"+  $scope.EmailSubject);
                        $scope.caseData = JSON.parse(data);

                        var totaldata = $scope.caseData;
                        $scope.opencasecount = totaldata.totalOpenCaseEmail;
                        $scope.closecasecount = totaldata.totalClosedCaseEmail;
                        $scope.postive_percentage = totaldata.positive_percentage;
                        $scope.nagative_percentage = totaldata.nagative_percentage;
                        $scope.neutral_percentage = totaldata.neutral_percentage;
                        $scope.escalatedarray = totaldata.escalated_cases;
                        $scope.escalatecount = $scope.escalatedarray.length;
                        //alert($scope.escalatecount);
                        $scope.opencasearray = totaldata.opencase;
                        $scope.currentcasearray = totaldata.currentsubject;
                        $scope.currentsubject = $scope.currentcasearray[0];
                        //alert(currentsubject);
                        $scope.mydata = JSON.stringify($scope.currentsubject);
                        //alert( $scope.mydata);
                        // alert(a.totalCloseCases);
                        // alert("total cases::"+a.length);
                        // for(var i=0;i<a.length;i++)
                        // {
                        //     if(a[i].caseStatus=="New")
                        //     {
                        //         $scope.opencasecount= $scope.opencasecount+1;
                        //     }
                        //     if(a[i].caseStatus=="Closed")
                        //     {
                        //         $scope.closecasecount=$scope.closecasecount+1;
                        //     }
                        // }
                        //  alert(" Total opencase::"+$scope.opencasecount);
                        //  alert(" Total closecase::"+$scope.closecasecount);

                        $scope.$apply();
                    }
                });
            }

            $scope.CloseCaseOpenPopup = function (item) {

                $scope.case = item;
                //alert($scope.case.caseNumber);
                $('.bs-example-modal-sm').modal('show');
            }

            $scope.CloseCase = function () {
                if ($scope.case.Reason) {
                    chrome.extension.sendRequest({
                        //  cmd: "bg_HttpGet_auth", urlName: "CoseCaseServlet", Query: { case_no: $scope.case.caseNumber, case_close_reason: $scope.case.Reason }
                        cmd: "bg_HttpGet_auth",
                        urlName: "CoseCaseServlet",
                        Query: {case_no: $scope.case.caseNumber, case_close_reason: $scope.case.Reason}

                    }, function (data) {
                        if (data) {
                            //alert($scope.InfoUserEmail);
                            alert('Case Closed Successfully!');
                            $scope.case = null;
                            $scope.DisplayCaseBasedOnEmail($scope.InfoUserEmail);
                            $('.bs-example-modal-sm').modal('hide');
                            $scope.$apply();
                        }
                    });
                } else {
                    alert('Please enter reason for close case.');
                }
            }

            $scope.SelectTemplate = function () {
                sdk.Compose.registerComposeViewHandler(function (composeView) {
                    composeView.setBodyHTML($scope.selectedEmailTemplate.temp_txt);
                });
            }

            $('#myTabs a').click(function (e) {
                e.preventDefault();
                $(this).tab('show');
            });

            //var delay = 1000, setTimeoutConst;
            //$(".AO").on("mouseenter", ".yX", function (evt) {
            //    setTimeoutConst = setTimeout(function () {
            //        var email = $(evt.target).find('.yP').attr('email');
            //        $scope.InfoUserEmail = email;
            //        $scope.$apply();
            //    }, delay);
            //}).on("mouseleave", ".yX", function () {
            //    clearTimeout(setTimeoutConst);
            //});
        });

        angular.bootstrap($('#mt-app'), ['myApp'], []);
        $("#mt-app").show();

        toastr.options.closeMethod = 'fadeOut';
        toastr.options.closeDuration = 300;
        toastr.options.closeEasing = 'swing';
    }, 3000);
});

var fa = document.createElement('style');
fa.type = 'text/css';
fa.textContent = '@font-face { font-family: FontAwesome; src: url("'
    + chrome.extension.getURL('thirdparty/font-awesome-4.7.0/fonts/fontawesome-webfont.woff')
    + '"); }';
document.head.appendChild(fa);
