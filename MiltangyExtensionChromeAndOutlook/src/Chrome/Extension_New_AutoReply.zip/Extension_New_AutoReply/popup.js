var app = angular.module("app", []);

app.config([
    '$compileProvider',
    function ($compileProvider) {
        var currentImgSrcSanitizationWhitelist = $compileProvider.imgSrcSanitizationWhitelist();
        var newImgSrcSanitizationWhiteList = currentImgSrcSanitizationWhitelist.toString().slice(0, -1)
        + '|chrome-extension:'
        + currentImgSrcSanitizationWhitelist.toString().slice(-1);

        console.log("Changing imgSrcSanitizationWhiteList from " + currentImgSrcSanitizationWhitelist + " to " + newImgSrcSanitizationWhiteList);
        $compileProvider.imgSrcSanitizationWhitelist(newImgSrcSanitizationWhiteList);
    }
]);

app.controller('searchController', function ($scope) {

    var Urls = {
        LOGIN_URL: "https://login.salesforce.com/services/oauth2/authorize?response_type=code&client_id=3MVG9d8..z.hDcPLTrjNrmyBE6aaQd4ppOmDoPDosVQgzlKdbddzLx48u68paKUn8o_UK2ZcZBFu9aQ7_DFPz&redirect_uri=https://application.mailtangy.com:8443/SFDC/redirect",
        LOGIN_CALLBACK_URL: "https://application.mailtangy.com:8443/SFDC/redirect",
        REFRESH_TOKEN_URL: "http://application.mailtangy.com:8080/SFDC/getTokenRefreshToken.token?type=code&code=",
        Tokan: "http://login.salesforce.com?grant_type=authorization_code&code=aPrxsmIEeqM9PiQroGEWx1UiMQd95_5JUZVEhsOFhS8EVvbfYBBJli2W5fn3zbo.8hojaNW_1g%3D%3D&client_id=3MVG9d8..z.hDcPLTrjNrmyBE6aaQd4ppOmDoPDosVQgzlKdbddzLx48u68paKUn8o_UK2ZcZBFu9aQ7_DFPz&client_secret=8775885422026143561&redirect_uri=https://application.mailtangy.com:8443/SFDC/redirect"
    }
    var loginTabId = null;

    var Credentials = {
        code: "",
        data: {}

    }

    $scope.OpenLogin = function () {
        chrome.tabs.create({ "url": Urls.LOGIN_URL, "selected": true }, function (tab) {
            loginTabId = tab.id;
        });
    }

    chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
        if (tab) {
            if (tab.url.indexOf(Urls.LOGIN_CALLBACK_URL) >= 0 && tab.status == "complete") {
                Credentials.code = getParameterByName("code", tab.url);
                // alert("code::"+code);
                console.log(Credentials.code);
                console.log(tab);
                console.log("------");
                $.ajax({
                    url: Urls.REFRESH_TOKEN_URL + Credentials.code,
					headers: {
						'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
					},
                    success: function (data) {
                //   alert(data);

                        console.log(data)
                    },
                });

                //chrome.tabs.remove(loginTabId, function () {
                //    loginTabId = null;
                //});
            }
        }
    });
       
    function getData() {
        $.ajax({
            url: "http://application.mailtangy.com:8080/SFDC/displayCase.allcase?rm_email=" + mail.currentuser + "&type=all",
			headers: {
						'Authorization': "BasicRealm bWFpbHRhbmd5QGJpemxlbS5jb206bWFpTFRhbmd5MTIhQEI="
					},
            data: {
                access_token: JSON.parse(JSON.stringify(mail.data)).access_token,
            },
            success: function (result) {
                //alert(result);
                var main_obj = JSON.parse(result);
                var toc_count = "Open Cases : " + main_obj.total_open_case;
                var tcc_count = "Closed Cases : " + main_obj.total_close_case;
                var toc_obj = main_obj.total_open_case_data;
                var tcc_obj = main_obj.total_close_case_data;
                var open_case_data = "";
                var close_case_data = "";
                //alert("toc_obj.length : "+toc_obj.length);
                for (i = 0; i < toc_obj.length; i++) {
                    open_case_data = open_case_data + '<div class="case_bg_toggled"><div class="case_bg_box"><h5><b></b></h5><div class="cases_icon_inner"><small><a href=' + toc_obj[i].lightning_URL + ' target="_blank">' + toc_obj[i].caseSubject + '</a></small><br><small class="pull-right">' + toc_obj[i].dateTimeOpened + '</small><br></div></div></div>';
                }
                //alert("tcc_obj.length : "+tcc_obj.length);
                for (i = 0; i < tcc_obj.length; i++) {
                    close_case_data = close_case_data + '<div class="case_bg_toggled"><div class="case_bg_box"><h5><b></b></h5><div class="cases_icon_inner"><small><a href=' + tcc_obj[i].lightning_URL + ' target="_blank">' + tcc_obj[i].caseSubject + '</a></small><br><small class="pull-right">' + tcc_obj[i].dateTimeClosed + '</small><br></div></div></div>';
                }
                document.getElementById("Open_Cases_Count").innerHTML = toc_count;
                document.getElementById("case_bg_toggled_main_toc").innerHTML = open_case_data;
                document.getElementById("Close_Cases_Count").innerHTML = tcc_count;
                document.getElementById("case_bg_toggled_main_tcc").innerHTML = close_case_data;
            }//success close
        });//ajax close
    }

    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

});

app.controller('opctionController', function ($scope) {

});

