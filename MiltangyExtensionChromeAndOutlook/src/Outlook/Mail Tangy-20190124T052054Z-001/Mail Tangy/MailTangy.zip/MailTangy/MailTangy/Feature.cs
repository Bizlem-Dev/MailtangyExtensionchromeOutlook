﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailTangy
{
    class Feature
    {
        public string Name { get; set; }
        public string FeatureImagePath { get; set; }
        public bool IsSelected { get; set; }
    }
}
