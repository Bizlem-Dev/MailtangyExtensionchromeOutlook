﻿using System.Windows.Controls;

namespace MailTangy
{
    /// <summary>
    /// Interaction logic for SearchResults.xaml
    /// </summary>
    public partial class SearchResults : UserControl
    {
        public SearchResults()
        {
            InitializeComponent();
            //this.DataContext = contactData;
        }
    }
}
